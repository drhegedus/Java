package assignment4Game;

public class Configuration {
	
	public int[][] board;
	public int[] available;
	boolean spaceLeft;
	
	public Configuration(){
		board = new int[7][6];
		available = new int[7];
		spaceLeft = true;
	}
	
	public void print(){
		System.out.println("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |");
		System.out.println("+---+---+---+---+---+---+---+");
		for (int i = 0; i < 6; i++){
			System.out.print("|");
			for (int j = 0; j < 7; j++){
				if (board[j][5-i] == 0){
					System.out.print("   |");
				}
				else{
					System.out.print(" "+ board[j][5-i]+" |");
				}
			}
			System.out.println();
		}
	}
	
	public void addDisk (int index, int player){
		int count = 0;
		if (this.available[index] < 6) {	
			if (this.board[index][this.available[index]] != 1 && this.board[index][this.available[index]] != 2) {
					this.board[index][this.available[index]] = player;
					this.available[index] ++;
			}
			for (int i = 0; i < 7 ; i++) {
				for (int j = 0; j < 6; j++) {
					if (this.board[i][j] == 1 || this.board[i][j] == 2) {
						count ++;
					}
				}
			}
			if (count == 42) { this.spaceLeft = false; }
		}
	}
	
	public boolean isWinning (int lastColumnPlayed, int player){
		int count = 0;
		
		//CASE 1: 3 to the left
			count = 0;
			if (lastColumnPlayed - 3 >= 0) {
				for (int i = 0; i < 4; i++) {
					if (this.board[lastColumnPlayed - i][heightOfCol(lastColumnPlayed) - 1] == player) {
						count ++;
					}
				}
			}
			if (count == 4) { return true; }
			
		//CASE 2: 3 to the right
			if (lastColumnPlayed + 3 < 7) {
				for (int i = 0; i < 4; i++) {
					if (this.board[lastColumnPlayed + i][heightOfCol(lastColumnPlayed) - 1] == player) {
						count ++;
					}
				}
			}
			if (count == 4) { return true; }
			
		//CASE 3: 1 to the left and 2 to the right
		count = 0;
		if (lastColumnPlayed - 1 >= 0) {
			if (this.board[lastColumnPlayed - 1][heightOfCol(lastColumnPlayed) - 1] == player) {
				count ++;
			}
		}
		if (lastColumnPlayed + 2 < 7) {
			for (int i = 0; i<3; i++) {
				if (this.board[lastColumnPlayed + i][heightOfCol(lastColumnPlayed) - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }	
			
		//CASE 4: 2 to the left and 1 to the right
		count = 0;
		if (lastColumnPlayed + 1 < 7) {
			if (this.board[lastColumnPlayed + 1][heightOfCol(lastColumnPlayed) - 1] == player) {
				count ++;
			}
		}
		if (lastColumnPlayed - 2 >= 0) {
			for (int i = 0; i<3; i++) {
				if (this.board[lastColumnPlayed - i][heightOfCol(lastColumnPlayed) - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }
		
		//CASE 5: Vertical Win
		count = 0;
		if (this.heightOfCol(lastColumnPlayed) >= 4) {
			for (int i = 0; i < 4; i++) {
				if (this.board[lastColumnPlayed][heightOfCol(lastColumnPlayed) - i - 1] == player) {
					count ++;
				}
			}
		}
		
		if (count == 4) { return true; }
			
		//CASE 6: right diag w/ bottom
		count = 0; 
		if (lastColumnPlayed - 3 >= 0 && heightOfCol(lastColumnPlayed) < 4) {
			for (int i = 0; i < 4; i++) {
				if (this.board[lastColumnPlayed - i][heightOfCol(lastColumnPlayed) + i - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }
			
		
		//CASE 7: right diag w/ 2nd to bottom
		count = 0; 
		if (lastColumnPlayed - 2 >= 0 && heightOfCol(lastColumnPlayed) < 5) 
		{
			for (int i = 0; i < 3; i++) {
				if (this.board[lastColumnPlayed - i][heightOfCol(lastColumnPlayed) + i - 1] == player) {
					count ++;
				}
			}
		}
		if (lastColumnPlayed + 1 < 7 && heightOfCol(lastColumnPlayed) > 1) {
			if (this.board[lastColumnPlayed + 1][heightOfCol(lastColumnPlayed) - 2] == player) {
				count ++;
			}
		}
		if (count == 4) { return true; }

		
		//CASE 8: right diag w/ 2nd to top
		count = 0; 
		if (lastColumnPlayed - 1 >= 0 && heightOfCol(lastColumnPlayed) < 6) {
			if (this.board[lastColumnPlayed - 1][heightOfCol(lastColumnPlayed)] == player) {
				count ++;
			}
		}
		if (lastColumnPlayed + 2 < 7 && heightOfCol(lastColumnPlayed) > 2) {
			for (int i = 0; i < 3; i++) {
				if (this.board[lastColumnPlayed + i][heightOfCol(lastColumnPlayed) - i - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }

		
		//CASE 9: right diag w/ top
		count = 0; 
		if (lastColumnPlayed + 3 < 7 && heightOfCol(lastColumnPlayed) > 3) {
			for (int i = 0; i < 4; i++) {
				if (this.board[lastColumnPlayed + i][heightOfCol(lastColumnPlayed) - i - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }

		
		//CASE 10: left diag w/ bottom
		count = 0; 
		if (lastColumnPlayed + 3 < 7 && heightOfCol(lastColumnPlayed) < 4) {
			for (int i = 0; i < 4; i++) {
				if (this.board[lastColumnPlayed + i][heightOfCol(lastColumnPlayed) + i - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }

		
		//CASE 11: left diag w/ 2nd to bottom
		count = 0; 
		if (lastColumnPlayed - 1 >= 0 && heightOfCol(lastColumnPlayed) > 1) {
			if (this.board[lastColumnPlayed - 1][heightOfCol(lastColumnPlayed) - 2] == player) {
				count ++;
			}
		}
		if (lastColumnPlayed + 2 < 7 && heightOfCol(lastColumnPlayed) < 5) {
			for (int i = 0; i < 3; i++) {
				if (this.board[lastColumnPlayed + i][heightOfCol(lastColumnPlayed) + i - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }

		
		//CASE 12: left diag w/ 2nd to top
		count = 0; 
		if (lastColumnPlayed - 2 >= 0 && heightOfCol(lastColumnPlayed) > 2) {
			for (int i = 0; i < 3; i++) {
				if (this.board[lastColumnPlayed - i][heightOfCol(lastColumnPlayed) - i - 1] == player) {
					count ++;
				}
			}
		}
		if (lastColumnPlayed + 1 < 7 && heightOfCol(lastColumnPlayed) > 6) {
			if (this.board[lastColumnPlayed + 1][heightOfCol(lastColumnPlayed)] == player) {
				count ++;
			}
		}
		if (count == 4) { return true; }

		
		//CASE 13: left diag w/ top
		count = 0; 
		if (lastColumnPlayed - 3 >= 0 && heightOfCol(lastColumnPlayed) > 3) {
			for (int i = 0; i < 4; i++) {
				if (this.board[lastColumnPlayed - i][heightOfCol(lastColumnPlayed) - i - 1] == player) {
					count ++;
				}
			}
		}
		if (count == 4) { return true; }

		return false;
	}
	
	public int canWinNextRound (int player){
		for (int i = 0; i < 7; i++) {
			if (this.available[i] < 6) { 
				this.addDisk(i, player); 
				if (this.isWinning(i, player) == true) {
					this.removeDisk(i);
					return i;
				}
				this.removeDisk(i);
			}
		}
		return -1; 
	}
	
	public int canWinTwoTurns (int player){
		 boolean wasAddedI=false;
	        boolean wasAddedJ=false;
	        int otherPlayer=0;
	        if (player==1) otherPlayer=2;
	        else otherPlayer=1;
	        for (int i=0; i<7; i++) {
	            this.addDisk(i, player);
	            wasAddedI=true;
	            int count=0;
	            for (int j=0; j<7; j++) {
	                wasAddedJ=true;
	                this.addDisk(j, otherPlayer);
	                if (this.canWinNextRound(player)!=-1 && this.isWinning(j, otherPlayer)==false)count++;
	                if (wasAddedJ==true) this.removeDisk(j);
	                wasAddedJ=false;
	            }
	            if (wasAddedI==true) this.removeDisk(i);
	            wasAddedI=false;
	            if (count==7) return i;
	        }
	        return -1;
	}
	
	public int heightOfCol(int index) {
		int count = 0;
		for (int i = 0; i < 6; i++) {
			if (this.board[index][i] != 0) {
				count ++;
			}
		}
		return count;
	}
	
	
	public void removeDisk (int index) {
		if ((this.available[index]) > 0) {
			if (this.board[index][this.available[index]-1] != 0) {
				this.board[index][this.available[index]-1] = 0;
				this.available[index] --;
			}
		}
	}
}
