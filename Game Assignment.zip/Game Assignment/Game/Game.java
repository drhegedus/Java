package assignment4Game;

import java.io.*;

public class Game {
	
	public static int play(InputStreamReader input){
		BufferedReader keyboard = new BufferedReader(input);
		Configuration c = new Configuration();
		int columnPlayed = 3; int player;
		
		// first move for player 1 (played by computer) : in the middle of the grid
		c.addDisk(firstMovePlayer1(), 1);
		int nbTurn = 1;
		
		while (nbTurn < 42){ // maximum of turns allowed by the size of the grid
			player = nbTurn %2 + 1;
			if (player == 2){
				columnPlayed = getNextMove(keyboard, c, 2);
			}
			if (player == 1){
				columnPlayed = movePlayer1(columnPlayed, c);
			}
			System.out.println(columnPlayed);
			c.addDisk(columnPlayed, player);
			if (c.isWinning(columnPlayed, player)){
				c.print();
				System.out.println("Congrats to player " + player + " !");
				return(player);
			}
			nbTurn++;
		}
		return -1;
	}
	
	public static int getNextMove(BufferedReader keyboard, Configuration c, int player){
		String currentLine;
		try {
			c.print();
			if (c.spaceLeft == true) {
				int otherPlayer;
				if (player == 1) { otherPlayer = 2; }
				else { otherPlayer = 1; }
				if (c.canWinNextRound(otherPlayer) != -1) {
					System.out.println("WARNING: Your opponent can win next round if they play in column: " + c.canWinNextRound(otherPlayer));
				}
				System.out.println("Please enter the column to play in.");
				currentLine = keyboard.readLine();
				while(currentLine != null) {
					while (currentLine != null) {
						int x = Integer.parseInt(currentLine);
						if (c.available[x] != 6 && x >= 0 && x < 7) {
							//c.addDisk(x, player);
							c.print();
							return x;
						}
						System.out.println("Column " + x + " is full. Enter a different column.");
						currentLine = keyboard.readLine();
					}
				}
				keyboard.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return -1;
	}
	
	public static int firstMovePlayer1 (){
		return 3;
	}
	
	public static int movePlayer1 (int columnPlayed2, Configuration c){
		if (c.spaceLeft == true) {
			int winning = c.canWinNextRound(1);
			if (winning != -1) {
				return winning;
			} else {
				int winInTwo = c.canWinTwoTurns(1);
				if (winInTwo != -1) {
					return winInTwo;
				} else if (c.available[columnPlayed2] < 6)  {
						return columnPlayed2;
				} else {
					for (int i = 1; i<7; i++) {
						int minus = columnPlayed2 - i;
						int plus = columnPlayed2 + i;
						if (minus < 7 && minus >= 0 && c.available[minus] < 6) {
							return minus;
						} else if (plus < 7 && plus >= 0 && c.available[plus] < 6) {
								return plus;
						}
					}
				}
			}
		}
		return -1;
	}
	
}
