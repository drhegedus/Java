//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: Extends student but with clarification of Part time

import java.util.ArrayList;
import java.util.HashMap;

//would check for fullTime boolean to be false in order to create one
public class PartTimeStudent extends Student {

	//PartTimeStudent is overloaded in case of different known values
	public PartTimeStudent(String name, String ID, boolean fullTime) {   }
	
	public PartTimeStudent(String name, String ID, boolean fulTime, ArrayList<Course> coursesTaken, HashMap<Course, Integer> history) {   }

}
