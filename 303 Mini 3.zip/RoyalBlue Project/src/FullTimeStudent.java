//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: Extends student but with clarification of Full time

import java.util.ArrayList;
import java.util.HashMap;

//would check for fullTime boolean to be true in order to create one
public class FullTimeStudent extends Student {
	
	//FullTimeStudent is overloaded in case of different known values
	public FullTimeStudent(String name, String ID, boolean fullTime) {   }
		
	public FullTimeStudent(String name, String ID, boolean fulTime, ArrayList<Course> coursesTaken, HashMap<Course, Integer> history) {   }
	
}
