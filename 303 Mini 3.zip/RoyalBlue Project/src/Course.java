//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: implements a course

import java.util.*;


public abstract class Course {
	private String name;						//every course has a name and list of the registered students
	private ArrayList<Student> registeredList;
	
	public Course(String name) {  }  //called if making a new course with no pre-registered students
	public Course(String name, ArrayList<Student> registeredList) {   } //overloads course -> if have pre-registered students at time of creation
}
