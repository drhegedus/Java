//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: Student functionality

import java.util.*;


public abstract class Student {

	private String name;
	private String ID;
	private ArrayList<Course> coursesTaken;
	private HashMap<Course, Integer> history;		//HashMap of history of course and grade
	private boolean fullTime;						//true if full time, false if part time
	private int courseAmount;						//depends on boolean fullTime -> if part time = 1 - 3, if full time = 4 - 6
	
	public Student(String name, String ID, boolean fullTime) {   }
	public Student(String name, String ID, boolean fullTime, ArrayList<Course> coursesTaken, HashMap<Course, Integer> history) {   }
	
	
	//get methods
	public boolean getFullTime() {   }		//will check if true -> full time ELSE part time
	
	public String getName() {   }
	
	public String getID() {   }
	
	public ArrayList<Course> getCoursesTaken() {   }
	
	public int getGrade(String courseName) {   }
	
	//set methods
	public void setName(String name) {   }
	
	public void setID(String ID) {   }
	
	
	//functional methods
	
	//takes a course and the grade wanted to be added
	public void addGrade(String courseName, int grade) {   }
	
	//takes the course name and add this Student instance to course
	public void registerToCourse(Course courseName) {   }
	
	//exits the program if nothing else is to be done - may print the final grades for students if wanted
	public void quitProgram() {  }


}
