//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: generalized framework for user interface

package GeneralizedFramework;

import java.util.Scanner;

//S = string, G = group, D = data, B = boolean for my reference
public class UserMain <P extends Person, G, D> {

	
	//same 4 options but generalized
	public void registerPerson(Scanner in, P person, G group) {  }
	
	public void addData(Scanner in, P person, D data) {  }
	
	public P newPerson(Scanner in) {  }
	
	public G newGroup(Scanner in){  }
	
	public quitProgram() {  }
}
