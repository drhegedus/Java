//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: generalized framework for Course --> Group

package GeneralizedFramework;

import java.util.*;


public abstract class Group <P extends Person> {
	private String name;
	private ArrayList<P> membersList;
	
	//overloaded again depending on what data you have upon creation of Group
	public Group(String name) {  }
	public Group(String name, ArrayList<P> membersList) {  }
	
	public void addPersontoGroup(P person) {  }
	
}
