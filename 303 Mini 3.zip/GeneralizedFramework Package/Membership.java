//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: generalized framework for Membership in group

package GeneralizedFramework;

import java.util.ArrayList;
import java.util.HashMap;

//S = string, G = group, D = data, B = boolean for my reference
public class Membership <M extends Person, S, G, D, B> {

	//overloaded method depending on what data is already known about person 
	//NOTE: ofType is equivalent to fullTime boolean in Royal Blue example
	public Membership(S name, S ID) {  }
	
	public Membership(S name, S ID, B ofType, ArrayList<G> groupsAlreadyIn, HashMap<G, D>)
}
