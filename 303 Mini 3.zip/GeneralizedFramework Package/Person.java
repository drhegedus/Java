//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: generalized framework for a Student ---> Person

package GeneralizedFramework;

import java.util.*;

//S = string, G = group, D = data (ie grade = int), B = boolean for my reference
public abstract class Person <S, G, D, B>{

	private S name;
	private S ID;
	private ArrayList<G> groupList;
	private HashMap<G, D> history;
	private B ofType; 	//like fullTime boolean in Royal Blue
	private D amount;	//like courseAmount in Royal Blue
	
	//overloaded depending on what data is known on person upon creation
	public Person (S name, S ID) {  }
	public Person (S name, S ID, ArrayList<G> groupList, HashMap<G, D> history) {  }
	
	public B isOfType() {  }		//returns true if of type1 Else of type 2
	
	
	//get methods
	public S getName() {  }
	
	public S getID() {  }
	
	public ArrayList<G> getGroupList() {  }
	
	public D getDataOfGroup(G group) {  }
	
	//set methods
	public void setName(S name) {  }
	
	public void setID(S ID) {  }
	
	//functional methods
	public void addDataToGroup(G group, D data) {  }
		
	public void addPersonToGroup(G group) {  }
}
