//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: Student functionality generic

import java.util.*;


public abstract class Student <C> {

	private String name;
	private String ID;
	private ArrayList<C> coursesTaken;
	private HashMap<C, Integer> history;		//HashMap of history of course and grade
	private boolean fullTime;						//true if full time, false if part time
	private int courseAmount;						//depends on boolean fullTime -> if part time = 1 - 3, if full time = 4 - 6
	
	public Student(String name, String ID, boolean fullTime) {   }
	public Student(String name, String ID, boolean fullTime, ArrayList<C> coursesTaken, HashMap<C, Integer> history) {   }
	
	
	//get methods
	public boolean getFullTime(Student s1) {   }
	
	public String getName() {   }
	
	public String getID() {   }
	
	public ArrayList<C> getCoursesTaken() {   }
	
	public int getGrade(String courseName) {   }
	
	//set methods
	public void setName(String name) {   }
	
	public void setID(String ID) {   }
	
	
	//functional methods
	
	//takes a course and the grade wanted to be added
	public void addGrade(String courseName, int grade) {   }
	
	//takes the course name and add this Student instance to course
	public void registerToCourse(C courseName) {   }
	


}
