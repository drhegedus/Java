//Creator: Daphne Hegedus 260762425
//Date: September 2018
//Purpose: User interface for Royal Blue Generics

import java.util.*;
import java.util.Scanner;


public class UserMain <S, C> {

	//class for all of the User I/O with scanner in initialized in main()
	public static void main(String[] args) {   }
	
	public void registerStudent(Scanner in, S s1, C c) {   }
	
	public void addGrade(Scanner in, S s1, C c) {  }
	
	public void Student newStudent(Scanner in) {  }
	
	public void Course newCourse(Scanner in) {   }
	
	public void quitProgram() {   }
}