
//Creator: Daphne Hegedus (260762425)
//Date: September 2018
//Purpose: Acquaintance Class for Contacts

public class ContactsFriend extends ContactsAcquaintance {
	//PRIVATE ATTRIBUTES
	private String address;
	private String birthday;
	
	//CONSTRUCTOR
	public ContactsFriend(String name, String phone, String address, String birthday) {
		super(name, phone);
		if (address != null && birthday != null) {
			this.address = address;
			this.birthday = birthday;
		} else throw new IllegalArgumentException("Invalid inputs for Contact");
	}

	//SET METHODS
	public void setAddress(String address) {
		if (address != null) {
			this.address = address;
		} else throw new IllegalArgumentException("Invalid inputs for address");
	}
	
	public void setBirthday(String birthday) {
		if (birthday != null) {
			this.birthday = birthday;
		} else throw new IllegalArgumentException("Invalid inputs for birthday");
	}
	
	//GET METHODS
	public String getAddress() {
		return this.address;
	}
	
	public String getBirthday() {
		return this.birthday;
	}
	
	//TOSTRING METHOD - in correct form/spacing for ListAll() in ContactsMain.java
	public String toString() {
		return super.getName() + padding(super.getName(), "name") + super.getPhone() + "      " + address + padding(address, "address") + birthday;
	}
}
