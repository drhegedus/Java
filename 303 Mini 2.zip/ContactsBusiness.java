
//Creator: Daphne Hegedus (260762425)
//Date: September 2018
//Purpose: Business Class for Contacts

public class ContactsBusiness extends ContactsAcquaintance {
	//PRIVATE ATTRIBUTES
	private String address;
	private String businessName;
	
	//CONSTRUCTOR
	public ContactsBusiness(String name, String phone, String address, String businessName) {
		super(name, phone);
		if (address != null && businessName != null) {
			this.address = address;
			this.businessName = businessName;
		} else throw new IllegalArgumentException("Invalid inputs for Contact");
	}
	
	//SET METHODS
	public void setAddress(String address) {
		if (address != null) {
			this.address = address;
		} else throw new IllegalArgumentException("Invalid inputs for address");
	}
	
	public void setBusinessName(String businessName) {
		if (businessName != null) {
			this.businessName = businessName;
		} else throw new IllegalArgumentException("Invalid inputs for business name");
	}
	
	//GET METHODS
	public String getAddress() {
		return this.address;
	}
	
	public String getBusinessName() {
		return this.businessName;
	}	
	
	//TOSTRING METHOD - in correct form/spacing for ListAll() in ContactsMain.java
	public String toString() {
		return super.getName() + padding(super.getName(), "name") + super.getPhone() + "      " + address + padding(address, "address") + "                    " + businessName;
	}
}
