
//Creator: Daphne Hegedus (260762425)
//Date: September 2018
//Purpose: Test all additional Contacts*.java program files

public class ContactsTest {
	public static void main (String[] arg) {
		System.out.println("WELCOME TO TESTER \n");
		
		
		constructorTest();
		setMethodsTest();
		paddingTest();
		toStringTest();
		setAddressTest();
		setBirthdayTest();
		setBusinessNameTest();
		newContactTest(); 
		searchForContactTest();
		toStringContactsListTest();
		
		System.out.println("\n \n ________________________________________________");
		System.out.println("ALL TESTS DONE: if no errors printed = all tests passed");
	}
	
	
	
	
	public static void constructorTest() {
		System.out.println("TESTING CONSTRUCTOR");
		try {
			ContactsAcquaintance a = new ContactsAcquaintance("Daphne Hegedus", "1234567890");
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		try {
			ContactsAcquaintance b = new ContactsAcquaintance("Jessica Haight",  null);		//null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception was expected = no problem
		}
		
		try {
			ContactsAcquaintance b = new ContactsAcquaintance(null,  "0987654321");			//null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception was expected = no problem
		}
		
		try {
			ContactsAcquaintance b = new ContactsAcquaintance("Jessica Haight",  "1");		//invalid phone number length
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception was expected = no problem
		}
		
		System.out.println("TEST DONE");
	}
	
	
	
	
	
	
	public static void setMethodsTest() {
		System.out.println("TESTING THE SET METHODS in acquaintances");
		
		ContactsAcquaintance a = new ContactsAcquaintance("Daphne","0123456789");

		//SETNAME()
		try {
			a.setName(null);																	//invalid null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			a.setName("Jessica Haight");														//valid
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		
		//SETPHONE()
		try {	
			a.setPhone(null);																	//invalid null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			a.setPhone("1");																	//set invalid phone length
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			a.setPhone("1111111111");															//valid
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		
		//SETNEXT()
		try {
			a.setNext(null);																	//invalid null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			ContactsAcquaintance b = new ContactsAcquaintance("Daphne Hegedus", "1111111111");
			a.setNext(b);																		//valid
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		
		
		System.out.println("TEST DONE");
	}
	
	
	
	
	
	public static void paddingTest() {
		System.out.println("TESTING PADDING");
		
		
		if (ContactsAcquaintance.padding(null,  null) != null) {
			System.out.println("Error. Input in invalid");
		} else if (ContactsAcquaintance.padding("Daphne Hegedus",  "name") == null) {
			System.out.println("Error. Input in valid but caught as invalid");
		}
		
		System.out.println("TEST DONE");
	}
	
	
	

	
	public static void toStringTest() {
		System.out.println("TESTING TOSTRING");
	
		//Testing toString in Acquaintances
		ContactsAcquaintance a = new ContactsAcquaintance("Daphne Hegedus", "4388685706");
		
		try {
			System.out.println("Should see: \nDaphne Hegedus      4388685706");
			System.out.println("We see: \n" + a.toString() + "\n");
		} catch (Exception e) {
			
		}
		
		//Testing toString in Businesses
		ContactsAcquaintance b = new ContactsBusiness("Lindsay", "1234567890", "13 McGill St", "McGill");
		
		try {
			System.out.println("Should see: \nLindsay             1234567890      13 McGill St                                           McGill");
			System.out.println("We see: \n" + b.toString() + "\n");
		} catch (Exception e) {
			
		}
		
		//Testing toString in Friends
		ContactsAcquaintance f = new ContactsFriend("Jessica Haight", "1111111111", "509 des Pins", "April 16 1999");
		
		try {
			System.out.println("Should see: \nJessica Haight      1111111111      509 des Pins                       April 16 1999");
			System.out.println("We see: \n" + f.toString() + "\n");
		} catch (Exception e) {
			
		}
		
		System.out.println("TEST DONE");
	}
	
	
	

	
	public static void setAddressTest() {
		System.out.println("TESTING SETADDRESS");
		
		ContactsFriend f = new ContactsFriend("Jessica Haight", "0987654321", "509 des Pins", "June 10 2000");
		ContactsBusiness b = new ContactsBusiness("Lindsay Day", "1111111111", "3550 Jeanne Mance", "McGill");
		
				
		//testing setAddress for ContactsFriend
		try {
			f.setAddress(null);																	//invalid null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			f.setAddress("1345 Milwaukee Ave");														//valid
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		
		//testing setAddress for ContactsBusiness
		try {
			b.setAddress(null);																	//invalid null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			b.setAddress("19513 Todd Lake");														//valid
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		
		System.out.println("TEST DONE");
	}
	
	
	
	
	public static void setBirthdayTest() {
		System.out.println("TESTING SETBIRTHDAY");
		
		ContactsFriend f = new ContactsFriend("Jessica Haight", "0987654321", "509 des Pins", "June 10 2000");
		
		try {
			f.setBirthday(null);																	//invalid null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			f.setBirthday("April 16 1999");															//valid
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		System.out.println("TEST DONE");
	}
	
	
	
	
	public static void setBusinessNameTest() {
		System.out.println("TESTING SETBUSINESSNAME");
		
		ContactsBusiness b = new ContactsBusiness("Lindsay Day", "1111111111", "3550 Jeanne Mance", "McGill");
		
		try {
			b.setBusinessName(null);																	//invalid null
			System.out.println("Error. Argument is invalid but no exception was caught.");
		} catch (Exception e) {
			//exception expected = no problem
		}
		
		try {
			b.setBusinessName("Microsoft");														//valid
		} catch (Exception e) {
			System.out.println("Error. Argument is valid but exception was caught.");
		}
		
		System.out.println("TEST DONE");
	}
	
	
	
	
	
	public static void newContactTest() {
		System.out.println("TESTING NEWCONTACT");
		
		ContactsList list = new ContactsList();
		ContactsAcquaintance a = new ContactsAcquaintance("Daphne", "1111111111");
		ContactsAcquaintance b = new ContactsAcquaintance("Daphne", "2222222222");
		ContactsAcquaintance c = new ContactsAcquaintance("Daphne", "3333333333");
		ContactsAcquaintance d = new ContactsAcquaintance("Daphne Hegedus", "1111111111");
		ContactsAcquaintance e = new ContactsAcquaintance("Jessica", "1111111111");
		ContactsAcquaintance f = new ContactsAcquaintance("Jessica", "2222222222");
		ContactsAcquaintance g = new ContactsAcquaintance("Lindsay", "1111111111");
		
		try {
			list.newContact(a);
			list.newContact(b);
			list.newContact(c);
			list.newContact(d);
			list.newContact(e);
			list.newContact(f);
			list.newContact(g);
		} catch (Exception ex){
			System.out.println("Error. Arguements are valid but exception was caught.");
		}
		
		
		System.out.println("TEST DONE");
	}
	
	
	
	
	public static void searchForContactTest() {
		System.out.println("TESTING SEARCHFORCONTACT");
		
		ContactsList list = new ContactsList();
		ContactsAcquaintance a = new ContactsAcquaintance("Daphne", "1111111111");
		ContactsAcquaintance b = new ContactsAcquaintance("Daphne", "2222222222");
		ContactsAcquaintance c = new ContactsAcquaintance("Daphne Hegedus", "1111111111");
	
		
		list.newContact(a);
		list.newContact(b);
		list.newContact(c);
		
		ContactsAcquaintance found = null;
		try {																			//valid
			found = list.searchForContact("Daphne");
			list.searchForContact("Daphne Hegedus");
			
		} catch (Exception ex) {
			System.out.println("Arguments are valid but exception was caught");
		}
		
		if (!found.getPhone().equals("1111111111")) {
			System.out.println("Error. found second entry instead of first");
		}
		
		System.out.println("We should see this contact does not exist. Searching for Jessica");
		try {																			//invalid
			list.searchForContact("Jessica");
		} catch (Exception ex) {
			//exception expected = no problem
		}
		System.out.println();
		
		System.out.println("TEST DONE");
	}
	
	
	
	
	
	public static void toStringContactsListTest() {
		System.out.println("TESTING TOSTRING in contacts list");
		
		ContactsList list = new ContactsList();
		ContactsAcquaintance a = new ContactsAcquaintance("Daphne","1234567890");
		ContactsAcquaintance b = new ContactsAcquaintance("Daphne","4388685706");
		ContactsAcquaintance c = new ContactsAcquaintance("Daphne","1111111111");
		ContactsBusiness d = new ContactsBusiness("Daphne Hegedus","5416391228", "3550 Jeanne Mance", "McGill");
		ContactsFriend e = new ContactsFriend("Daphne Hegedus","5416474653","1345 Milwaukee", "April 16 1999");
		ContactsFriend f = new ContactsFriend("Jessica Haight","2222222222","509 des Pins", "June 10 2000");
		ContactsAcquaintance g = new ContactsAcquaintance("Lindsay","0987654321");
		
		
		list.newContact(a);
		list.newContact(b);
		list.newContact(c);
		list.newContact(d);
		list.newContact(e);
		list.newContact(f);
		list.newContact(g);
		
		System.out.println("We expect to see 7 entries with 3 Daphne, 2 Daphne Hegedus, 1 Jessica Haight, and 1 Lindsay with all their info");
		System.out.println("\n" + list.toString());
		
		System.out.println("TEST DONE");
	}
	
	
	

}
