
//Creator: Daphne Hegedus (260762425)
//Date: September 2018
//Purpose: User Interface for Contacts


import java.util.Scanner;
import java.util.*;
public class ContactsMain {

	public static void main(String args[]) {
		Scanner UI = new Scanner(System.in);
		
		System.out.println("Welcome to your Contacts!");
		ContactsList myList = new ContactsList();															//ContactsList for this run -> will be passed to all helper methods
		
		int option = 0;																						//initialized option as 0 so it can enter the while loop the first time
		while (option < 1) {	
			System.out.println("1.  New Contact");															//prints out option menu
			System.out.println("2.  Find Contact");
			System.out.println("3.  List All");
			System.out.println("4.  Quit");
		    System.out.print("Please chose an option by entering a number from 1 - 4: ");	
		    String next = UI.nextLine();																	//scanner gets input from user
		    
		    try {
		    	option = Integer.parseInt(next);															//checks that input is an integer
		    } catch (NumberFormatException exp) {
		    	System.out.println("Option must be an integer. \n");	
		    	continue;
		    }
		    
		    if (option < 1 || option > 4 ) {																//check if between 1 and 4 , otherwise display error and ask again
		    	System.out.println("Option must be between 1 and 4. \n");
		    }
		    
		    
		    //option is now an int between 1 and 4
		    if (option == 4) {
		    	System.out.println(" \n \n------------------------------------------");
		    	System.out.println("Thank you for using Contacts.");
		    	break;																						//prints ending message and exits loop -> terminating program
		    }
			else if (option == 1) newContact(myList, UI);													//calls corresponding methods for each viable option
			else if (option == 2) findContact(myList, UI);
			else if (option == 3) listAll(myList);
		    option = 0;																						//resets option = 0 so it enters loop again
		}

	}
	
	
	
	
	public static void newContact(ContactsList myList, Scanner UI) {
		int type = 0;
		while (type < 1) {
			System.out.println();
			System.out.println("1. Acquaintance");															//New Contact Type options
			System.out.println("2. Business");
			System.out.println("3. Friend");
			System.out.print("What kind of contact would you like to create? Enter number 1 - 3 respectively: ");
			String next = UI.nextLine();																	//User choice fore type is checked in the same way as the main menu is
			
			try {
				type = Integer.parseInt(next);
			} catch (NumberFormatException exp) {
				System.out.println("Option must be an integer. \n");	
		    	continue;
			}
			
			if (type < 1 || type > 3 ) {																	//check if between 1 and 3 , otherwise display error and ask again
		    	System.out.println("Option must be between 1 and 3. \n");
			}
		}
		
		//all contacts will have a name and phone number
		System.out.println("What do you want your Contact's name to be? ");																					
		String name = UI.nextLine();																		//nextLine() allows spaces so it is used here instead of next()
		while (name == null || name.length() > 20) {
			System.out.println("Invalid name. Enter a name with 20 characters or less.");													//checks if it is a valid input
			name = UI.nextLine();
		}
		
		System.out.print("What is " + name + "'s phone number? ");
		String phone = UI.nextLine();
		while (phone == null || phone.length() != 10) {														//checks if valid 10 digit phone number
			System.out.print("Invalid phone number. Enter a number with 10 digits: ");
			phone = UI.nextLine();
		}
		
		if (type == 1) {																					//if user chose acquaintance it creates one
			ContactsAcquaintance acquaintance = new ContactsAcquaintance(name, phone);
			myList.newContact(acquaintance);																//adds contact to contact list
			System.out.println("\n" + name + "'s contact has been added to your contact list.");
		}
		else if (type == 2) {																				//if user chose business it creates one after asking for address and business name
			System.out.print("What is " + name + "'s business name? ");
			String businessName = UI.nextLine();
			while (businessName == null || businessName.length() > 20) {
				System.out.println("Invalid Business Name. Enter a name with 20 characters or less.");													//checks if it is a valid input
				businessName = UI.nextLine();
			}
			System.out.print("What is " + businessName + "'s address? ");
			String businessAddress = UI.nextLine();
			while (businessAddress == null || businessAddress.length() > 35) {
				System.out.println("Invalid Address. Enter a name with 35 characters or less.");													//checks if it is a valid input
				businessAddress = UI.nextLine();
			}
			
			ContactsAcquaintance business = new ContactsBusiness(name, phone, businessAddress, businessName);
			myList.newContact(business);
			System.out.println("\n" + name + "'s contact has been added to your contact list.");
		}
		else if (type == 3) {																				//if user chose friend it creates one after asking for address and birthday
			System.out.print("What is " + name + "'s address? ");
			String friendAddress = UI.nextLine();
			while (friendAddress == null || friendAddress.length() > 35) {
				System.out.println("Invalid Address. Enter a name with 35 characters or less.");													//checks if it is a valid input
				friendAddress = UI.nextLine();
			}
			System.out.print("What is " + name + "'s birthday? ");
			String birthday = UI.nextLine();
			while (birthday == null) {
				System.out.println("Invalid birthday. Try again.");													//checks if it is a valid input
				birthday = UI.nextLine();
			}
			
			ContactsAcquaintance friend = new ContactsFriend(name, phone, friendAddress, birthday);
			myList.newContact(friend);
			System.out.println("\n" + name + "'s contact has been added to your contact list.");
		}
		
		System.out.println("------------------------------------------");
		System.out.println("What would you like to do next? \n ");
	}
	
	
	
	
	public static void findContact(ContactsList myList, Scanner UI) {
		System.out.println("What is the name of the contact you are looking for?");						//asks user for contacts name that they are looking for
		String name = UI.nextLine();
		
		try {																							//try catch block to protect program
			ContactsAcquaintance found = myList.searchForContact(name);									//calls searchForContact in ContactsList class to see if contact exists already
			if (found != null) {																		//searchForContact returns null is no contact is found, thus if != null, contact exists
				System.out.println(found.getName());													//prints out name and phone number
				System.out.println(found.getPhone());
				if (found instanceof ContactsBusiness) {												//if it is a Business type -> prints out the additional values
					System.out.println(((ContactsBusiness)found).getAddress());
					System.out.println(((ContactsBusiness)found).getBusinessName());
				}
				if (found instanceof ContactsFriend) {													//if it is a Business type -> prints out the additional values
					System.out.println(((ContactsFriend)found).getAddress());
					System.out.println(((ContactsFriend)found).getBirthday());
				}
			}
		} catch (IllegalArgumentException e) {
			System.out.println("Invalid name entered.");
		}
		
		
		System.out.println("\n------------------------------------------");
		System.out.println("What would you like to do next? \n ");
	}
	
	
	
	
	
	public static void listAll(ContactsList myList) {
		System.out.println();
		System.out.println(myList.toString());
		
		
		System.out.println("\n------------------------------------------");
		System.out.println("What would you like to do next? \n ");
		
	}
	
}
