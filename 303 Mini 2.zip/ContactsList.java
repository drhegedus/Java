
//Creator: Daphne Hegedus (260762425)
//Date: September 2018
//Purpose: Compile the list of all contacts in a users contact list

import java.util.*;
public class ContactsList {
	
	//PRIVATE ATTRIBUTES
	private HashMap <String, ContactsAcquaintance> list;
	
	//CONSTRUCTOR
	public ContactsList() {
		list = new HashMap <String, ContactsAcquaintance>();
	}
	
	
	//Adds contact to list
	public void newContact(ContactsAcquaintance person) {										//if name entered is null -> throws exception									
		if (person.getName() == null) throw new IllegalArgumentException("Invalid contact.");
		
		else if (list.containsKey(person.getName())) {											//if contact already exists with that name -> finds the first contact with that name with next = null
			ContactsAcquaintance curr = list.get(person.getName());								//set person as that found contact.setNext(person)
			
			if (curr.getNext() == null) {
				curr.setNext(person);
			} else {
				ContactsAcquaintance pointer = curr;
				while (pointer.getNext() != null) {
					pointer = pointer.getNext();
				}
				pointer.setNext(person);
				
			}
		}
		
		else list.put(person.getName(), person);												//otherwise puts contact in list
	}
	
	
	//looks to see if contact is in list and return it if so, otherwise returns null
	public ContactsAcquaintance searchForContact(String name) {
		if (name == null) throw new IllegalArgumentException("Invalid name entered.");
		
		else if (!list.containsKey(name)) {														//if contact not in list -> tells user and returns null
			System.out.println("This contact does not exist.");									//if is in list -> returns contact
			return null;
		}
		
		else return list.get(name);																//if is in list -> returns contact

	}
	
	
	//PADDING METHOD - for lining up
		public String padding(String word, String type) {
			String padding = "";
			int paddingAmount = 0;
			
			if (type == "address") paddingAmount = 35 - word.length();							//Address are typically longer than the other parameters = 35 instead
			else paddingAmount = 20 - word.length();								
		
			for (int i= 0; i<paddingAmount; i++) {
				padding += " ";
			}
			return padding;
		}
	
	
	//puts list into printing form for listAll() in ContactsMain
	public String toString() {
		String printList = "";
		printList = "NAME"+ padding("NAME","name") + "PHONE NUMBER    " + "ADDRESS" + padding("ADDRESS","address") + "BIRTHDAY" + padding("BIRTHDAY","birthday") + "BUSINESS NAME" + "\n";
		for (Map.Entry<String, ContactsAcquaintance> info : list.entrySet()) {
			
			if(info.getValue().getNext() != null) {
			
				ContactsAcquaintance curr = info.getValue();
				while (curr.getNext() != null) {
				
					if (curr instanceof ContactsFriend) {							//Checks to see if every contact in list is a Friend -> toString w/in Friend class
						printList += ((ContactsFriend)(curr)).toString() + "\n";
					
					} else if (curr instanceof ContactsBusiness) {					//Checks to see if every contact in list is a Business -> toString w/in Business class
						printList += ((ContactsBusiness)(curr)).toString() + "\n";
						
					} else printList += curr.toString() + "\n";						//Contact is Acquaintance -> toString w/in Acquaintance class
						
					curr = curr.getNext();
				}
				if (curr != null) printList += curr.toString() + "\n";
			
			
			} else {
				if (info.getValue() instanceof ContactsFriend) {							//Checks to see if every contact in list is a Friend -> toString w/in Friend class
					printList += ((ContactsFriend)(info.getValue())).toString() + "\n";
				
				} else if (info.getValue() instanceof ContactsBusiness) {					//Checks to see if every contact in list is a Business -> toString w/in Business class
					printList += ((ContactsBusiness)(info.getValue())).toString() + "\n";
					
				} else printList += info.getValue().toString() + "\n";						//Contact is Acquaintance -> toString w/in Acquaintance class
			}
			
		}
		return printList;																		//returns the final list
	}
}
