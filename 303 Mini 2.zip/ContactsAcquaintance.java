
//Creator: Daphne Hegedus (260762425)
//Date: September 2018
//Purpose: Acquaintance Class for Contacts

public class ContactsAcquaintance {
	//PRIVATE ATTRIBUTES
	private String name;
	private String phone;
	private ContactsAcquaintance next;												//in case there is a contact with the same name/key -> points to next one with that key

	
	//CONSTRUCTOR
	ContactsAcquaintance(String name, String phone) {
		if (name != null && phone != null && phone.length() == 10) {
			this.name = name;
			this.phone = phone;
			this.next = null;															//initializes next as null until called and changed with setNext()
		} else throw new IllegalArgumentException("Invalid inputs for Contact");
	}
	
	//SET METHODS
	public void setName(String name) {
		if (name != null) {
			this.name = name;
		} else throw new IllegalArgumentException("Invalid inputs for name");
		
	}
	
	public void setPhone(String phone) {
		if (phone != null && phone.length() == 10) {
			this.phone = phone;
		} else throw new IllegalArgumentException("Invalid inputs for phone number");
	}
	
	public void setNext(ContactsAcquaintance next) {
		if (next != null) {
			this.next = next;
		} else throw new IllegalArgumentException("Invalid inputs for Next");
	}
	
	//GET METHODS
	public String getName() {
		return this.name;
	}
	
	public String getPhone() {
		return this.phone;
	}
	
	public ContactsAcquaintance getNext() {
		return this.next;
	}
	
	//PADDING METHOD - for lining up
	public static String padding(String word, String type) {
		String padding = "";
		int paddingAmount = 0;
		
		if (type == null || word == null) return null;
			if (type == "address") paddingAmount = 35 - word.length();
			else paddingAmount = 20 - word.length();		
		
		for (int i= 0; i<paddingAmount; i++) {
			padding += " ";
		}
		return padding;
	}
	
	
	//TOSTRING METHOD - in correct form/spacing for ListAll() in ContactsMain.java
	public String toString() {
		String info = name + padding(name, "name") + phone;
		return info;
	}
}
