/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */

import java.util.*;


public class OrderingSystem { //Singleton too
	
	private Menu menu;
	private static OrderingSystem INSTANCE = null;
	
	
	//wraps the private singleton ordering system
	public static OrderingSystem getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new OrderingSystem();
		}
		return INSTANCE;
	}
	
	private OrderingSystem() {
		this.menu = Menu.getInstance(); //Singleton
	}
	
	//creates a new instance of order
	public Order newOrder() {
		Order d = new Order();
		return d;
	}
	
	//returns the full menu from the OS POV
	public ArrayList<Item> listOfAllItems() {
		return menu.getMenu();
	}
	
	//adds an item to the order by checking that the item is on the menu (calls menu.orderItem())
	public void addItem(String name, String type, Order order) {
		Item i = menu.orderItem(name, type);
		if (i instanceof Drink && ((Drink)i).getAlcoholic()) {								//prints out the alcoholic message
			System.out.println("DRINK HAS ALCOHOL. Customer must be 18 years or older.");
		}
		if (i.getName().equals(menu.itemOfTheDay.getName())) {								//if the item is the item of the day it makes it a discounted item before adding to the order
			DiscountItem discountedI = menu.itemOfTheDay;
			order.addToOrder(discountedI);
		} else {
			order.addToOrder(i);
		}
	}
	
	
	//called at the end of a customers order to check if it fits the full meal criteria
	public Order makeFullMeal(Order order) {
		if (order.isFullMeal) {					//as we added items to an order we updated the isFullMeal boolean so this is the updated boolean
			for(Iterator<MenuItem> t = order.getOrder().iterator(); t.hasNext();) {		//for every item on the order it uses an iterator to traverse the items
				MenuItem i = t.next();
				//at the first instance of a dessert -> sets it to half off
				//CASE ONE: dessert is already discounted = add the 50% off on top of the existing discount
				if (i instanceof DiscountItem && ((DiscountItem) i).getItem().getType().equals("Dessert")) {		
					((DiscountItem) i).setDiscount(0.50);
					break;
				//CASE TWO: dessert found is a regular priced item = make it discounted at 50% off
				} else {
					Item i1 = ((Item)i);
					if (i1.getType().equals("Dessert")) { 
						DiscountItem d= new DiscountItem(i1, 0.50);
						t.remove();										//remove the regular priced item from the order
						order.addToOrder(d);							//add the discounted item
						break;
					}
				}

			}
		}
		return order;	
	}
	
	//called by OS when a customer wants to check out and pay
	public double finalize(Order order) {
		Order finalizedO = makeFullMeal(order);	//checks if it is a full meal (will apply the dessert discount in the function if it is)
		return finalizedO.total();				//returns the total price for payment
	}
}
