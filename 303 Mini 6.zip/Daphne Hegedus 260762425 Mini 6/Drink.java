/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */


//drinks are items but may be alcoholic
public class Drink extends Item {
	private boolean alcoholic;
	
	public Drink(String name, double price, boolean alcohol) { //boolean signals if alcoholic
		super(name, price, "Drink");
		this.alcoholic = alcohol;
	}
	
	public boolean getAlcoholic() {
		return this.alcoholic;
	}
}
