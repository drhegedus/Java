/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */

import java.util.*;

public class Order {
	private ArrayList<MenuItem> orderedItems;
	boolean isFullMeal;
	private double total;
	
	//Overloaded constructor header to be if new empty order or one that already has some items
	public Order(ArrayList<MenuItem> items) {
		for (Iterator<MenuItem> i = orderedItems.iterator(); i.hasNext();) {		//if has items it uses an iterator to go through every item (don't care if discounted or regular)
			MenuItem newItem = i.next();
			orderedItems.add(newItem);												//adds item to the order
		}
		setIsFullMeal();															//checks and sets the isFullMeal boolean
	}
	
	//case where it is a new empty order
	public Order() {
		this.orderedItems = new ArrayList<MenuItem>();	//make empty list
		setIsFullMeal();								//set full meal with always set it to false here cause nothing to check
	}
	
	//returns all items on the order
	public ArrayList<MenuItem> getOrder() {
		return this.orderedItems;
	}

	//checks if meets critera of full meal (will be called whenever making a new order or adding a item to order) to update isFullMeal boolean
	public void setIsFullMeal() {
		boolean full = false;
		boolean a, m, d;	//a = appetizer, m = main, d = dessert
		a = m = d = false;
		for (MenuItem i : orderedItems) {	//looks through all ordered items and updates booleans if finds a app, main, or dessert
			//decorator pattern allows us to call getType() on all items (discounted or not) and they will be handled accordingly
			if (i.getType().equals("Appetizer")) a = true;
			else if (i.getType().equals("Main")) m = true;
			else if (i.getType().equals("Dessert")) d = true;
		}
		if (a && m && d) full = true;
		this.isFullMeal = full;			//if has a m and d -> is a full meal = true
	}
	
	//adds a specific item (discounted or not) to the order and updates the isFullMeal boolean
	public void addToOrder(MenuItem i) {
		this.orderedItems.add(i);
		setIsFullMeal();
	}
	
	//uses iterator to look through all items in order to add up the order total price
	public double total() {
		double total = 0.0;
		for (Iterator<MenuItem> t = orderedItems.iterator(); t.hasNext();) {
			MenuItem i = t.next();
			//decorator pattern allows us to call getPrice() on all items (discounted or not) and they will be handled accordingly
			total = i.getPrice();
		}
		return total;
	}
	
	public String toString() {
		String bill = "--------------------- \nBILL: \n";
			if (this.isFullMeal) bill += "Order is a Full Meal!\n";
			for (Iterator<MenuItem> t = orderedItems.iterator(); t.hasNext();) {
				MenuItem i = t.next();
				//decorator pattern allows us to call getName() on all items (discounted or not) and they will be handled accordingly
				bill += i.getName() + Menu.padding(i.getName()) + (i.getPrice()) + "\n";

			}
			bill += "TOTAL: " + this.total() + "\n";
			return bill;
	}
	
}
