/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */

public class Item implements MenuItem { //implements because composite type of MenuItem

	private String name;
	private double price;
	private String type;
	
	public Item(String name, double price, String type) {
		this.name = name;
		this.price = price;
		if (type.equals("Main")) this.type = type;
		else if (type.equals("Appetizer")) this.type = type;
		else if (type.equals("Drink")) this.type = type;
		else if (type.equals("Side")) this.type = type;
		else if (type.equals("Dessert")) this.type = type;
		else throw new IllegalArgumentException("Your item is not a valid type of item.");
	}
	
	public double getPrice() {
		return this.price;
	}

	public String getName() {
		return this.name;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getType() {
		return this.type;
	}
	
}
