/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */
public class Driver {

	public static void main(String[] args) {
		//singletons
		Menu menu = Menu.getInstance();
		OrderingSystem os = OrderingSystem.getInstance();
		
		
		// print the menu
		System.out.println(menu.toString());
		
		// Create new order 
		Order order = new Order();
		
		// order an appetizer, a drink, and a dessert (orders 2 for testing that only one is discounted in full meal)
		os.addItem("Soup", "Appetizer", order);
		os.addItem("Chicken", "Main", order);
		os.addItem("Pie", "Dessert", order);

		os.addItem("Ice Cream", "Dessert", order);
		
		// order a beer - message should display
		os.addItem("Beer", "Drink", order);
		// item of the day - should be discounted
		os.addItem("Fries", "Side", order);
		
		// finalize and pay
		os.finalize(order);
		//print out the bill
		System.out.println(order.toString());
	}
	
}
