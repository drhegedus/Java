/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */

//Uses a Combo of the Composite and the Decorator Pattern (to deal with discounted items)
//want this because the order is a composite of MenuItems (discounted or regular)
//but when ordering the items, we treat discounted ones slightly differently than regular

public interface MenuItem {	//interface as per the Composite pattern

	public void setPrice(double price);
	public double getPrice();
	public String getName();
	public String getType();
}
