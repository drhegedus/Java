/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */


//Decorator pattern for dealing with discounted items
public class DiscountItem implements MenuItem {	//implements because composite type of MenuItem
	
	private Item i;
	private double price;
	private double discount;
	
	public DiscountItem(Item i, double discount) {
		this.i = i;
		this.discount = discount;
		this.price = getPrice();	//calls getPrice in this class to apply the discount
	}
	
	//returns that Item that the discount item is based on if want to find original price
	public Item getItem() {
		return this.i;
	}
	
	public String getName() {
		return this.i.getName();
	}
	
	public String getType() {
		return i.getType();
	}
	
	//applies the discount to the price (discount in for .25 meaning 25%)
	public double getPrice() {
		double newPrice = this.i.getPrice() * (1-discount);
		return newPrice;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	//if adding on an additional discount -> updates the price too
	public void setDiscount(double discount) {
		this.discount += discount;
		setPrice(getPrice());
	}
}
