/*
 * Creator: Daphne Hegedus 260762425
 * Date: November 2018
 */

import java.util.*;

//Menu is a singleton because we hard-coded in ONLY ONE MENU
public class Menu {
	ArrayList<Item> appetizers;
	ArrayList<Item> drinks;
	ArrayList<Item> sides;
	ArrayList<Item> mains;
	ArrayList<Item> desserts;
	private static Menu INSTANCE;
	DiscountItem itemOfTheDay;
	
	//public static Instance method -> wraps the singleton private Menu
	public static Menu getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new Menu();
		} 
		return INSTANCE;
	}
	
	private Menu() {
		appetizers = new ArrayList<Item>();
		Item a1 = new Item("Salad", 6.50, "Appetizer");
		Item a2 = new Item("Soup", 5.00, "Appetizer");
		appetizers.add(a1);
		appetizers.add(a2);
		drinks = new ArrayList<Item>();
		Drink dr1 = new Drink("Beer", 3.00, true);
		Item dr2 = new Drink("Wine", 3.50, true);
		Item dr3 = new Drink("Soda", 2.00, false);
		drinks.add(dr1);
		drinks.add(dr2);
		drinks.add(dr3);
		sides = new ArrayList<Item>();
		Item s1 = new Item("Fries", 4.00, "Side");
		Item s2 = new Item("Broccoli", 4.75, "Side");
		sides.add(s1);
		sides.add(s2);
		mains = new ArrayList<Item>();
		Item m1 = new Item("Chicken", 12.00, "Main");
		Item m2 = new Item("Fish", 14.50, "Main");
		mains.add(m1);
		mains.add(m2);
		desserts = new ArrayList<Item>();
		Item de1 = new Item("Pie", 5.00, "Dessert");
		Item de2 = new Item("Ice Cream", 4.50, "Dessert");
		desserts.add(de1);
		desserts.add(de2);
		setItemOfTheDay(s1, .25); //hard coded a 25% discount for item of the day
	}
	
	//can be easily set from the driver at the beginning of each day
	public void setItemOfTheDay(Item i, double discount) {
		DiscountItem d = new DiscountItem(i, discount); 
		this.itemOfTheDay = d;
	}
	
	//returns the list of all items on the menu
	public ArrayList<Item> getMenu() {
		ArrayList<Item> menu = new ArrayList<Item>();
		menu.addAll(this.appetizers);
		menu.addAll(this.drinks);
		menu.addAll(this.sides);
		menu.addAll(this.mains);
		menu.addAll(this.desserts);
		return menu;
	}
	
	
	//returns the item ordered only if item exists on menu, else returns a null item
	public Item orderItem(String name, String type) {
		Item i1 = null; 
		if (type.equals("Appetizer")) {
			for(Iterator<Item> t = appetizers.iterator(); t.hasNext();) {
				Item i = t.next();
				if (i.getName().equals(name)) return i;
			}
		}
		else if (type.equals("Main")) {
			for(Iterator<Item> t = mains.iterator(); t.hasNext();) {
				Item i = t.next();
				if (i.getName().equals(name)) return i;
			}
		}
		else if (type.equals("Dessert")) {
			for(Iterator<Item> t = desserts.iterator(); t.hasNext();) {
				Item i = t.next();
				if (i.getName().equals(name)) return i;
			}
		}
		else if (type.equals("Side")) {
			for(Iterator<Item> t = sides.iterator(); t.hasNext();) {
				Item i = t.next();
				if (i.getName().equals(name)) return i;
			}
		}
		else if (type.equals("Drink")) {
			for(Iterator<Item> t = drinks.iterator(); t.hasNext();) {
				Item i = t.next();
				if (i.getName().equals(name)) return i;
			}
		}
		return i1;

	}
	
	//for lining up the toString method
	public static String padding(String word) {
		String padding ="";
		int padNumber;

		// otherwise 15 spaces long
		padNumber = 15-word.length();

		for (int i=0; i<padNumber; i++) {
			padding +=" ";
		}
		return padding;
	}
	
	
	//for printing purposes (utilizes padding() to line up)
	public String toString() {
		String visual = "MENU \n \n";
		visual += "APPETIZERS: \n";
		for (Item i : this.appetizers) {
			visual += i.getName() + padding(i.getName()) + i.getPrice() + "\n";
		}
		visual += "\nSIDES: \n";
		for (Item i : this.sides) {
			visual += i.getName() + padding(i.getName()) + i.getPrice() + "\n";
		}
		visual += "\nMAINS: \n";
		for (Item i : this.mains) {
			visual += i.getName() + padding(i.getName()) + i.getPrice() + "\n";
		}
		visual += "\nDESSERTS: \n";
		for (Item i : this.desserts) {
			visual += i.getName() + padding(i.getName()) + i.getPrice() + "\n";
		}
		visual += "\nDRINKS: \n";
		for (Item i : this.drinks) {
			visual += i.getName() + padding(i.getName()) + i.getPrice() + "\n";
		}
		visual += "\nITEM OF THE DAY IS: \n" + itemOfTheDay.getName() + "       " + itemOfTheDay.getPrice() + "\n";
		return visual;
	}

	

}
