//Creator: Daphne Hegedus
//ID: 260762425
//Date: November 2018
//Collaborators: Haylee Luu

import java.io.*;

public class islands {
	
	private static int height;
	private static int width;

	public static void main(String[] args) {
		
		//FOR TIME CHECKING :
		//long startTime = System.currentTimeMillis();
		
		int[] answers = loadAndCall("testIslands.txt"); //loads in the fill info and calls find answer on every problem
		
		//writes all the answers - in correct format - to file
		writeAnswer("testIslands_solution.txt", answers);
		
		//FOR TIME CHECKING:
		//long endTime   = System.currentTimeMillis();
		//long totalTime = endTime - startTime;
		//System.out.println(totalTime);
		
	}
	
	//open the file and call findAnswer on every problem
	public static int[] loadAndCall(String fileName) {
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);

			int numOfProblems = Integer.parseInt(br.readLine());
			
			int[] answers = new int[numOfProblems];	//will be what we return
			
			for (int problem = 0; problem < numOfProblems; problem ++) {
				String dimensions = br.readLine();	
				String[] hw = dimensions.split(" "); //hw = height width
				height = Integer.parseInt(hw[0]);
				width = Integer.parseInt(hw[1]);
				
				
				char[][] display = new char[height][width];	//display will be size specified
				
				for (int i = 0; i < height; i++) {
					String s = br.readLine();
					for (int j = 0; j < s.length(); j++) {
						display[i][j] = s.charAt(j);
					}
					
				}
				answers[problem] = countIslands(display);	//solve this problem then move to next after storing answer
			}
			
			//close readers
			br.close();
			fr.close();
			
			//return the array of answers
			return answers;
			
		} catch (FileNotFoundException e1) {
			System.out.println("File not found.");
			e1.printStackTrace();
			return null;
		} catch (IOException e2) {
			System.out.println("IO Exception caught");
			e2.printStackTrace();
			return null;
		}
	}
	
	//implements a Strongly Connected Components algorithm with DFS
	public static int countIslands(char[][] display) {
		int numOfIslands = 0;			//will add up number of islands found
		
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				if (display[i][j] == '-') {
					DFS(display, i, j);
					numOfIslands ++;
				}
			}
		}
		return numOfIslands;			// return number of islands found
	}
	
	//checks that the index given is safe to check
	public static boolean isSafe(char[][] display, int row, int col) {
		return ((row >= 0) && (row < height) && (col >= 0) && (col < width) && display[row][col] == '-');
	}
	
	
	
	public static void DFS(char[][] display, int row, int col) {
		// represent coordinates of adjacent chars (height, width) -> above (-1, 0), left (0, -1), right (0, 1), below (1, 0)
		int[] rowNum = {-1, 0, 0, 1};
		int[] colNum = {0, -1, 1, 0};
		
		//like marking as visited -> change to water symbol
		display[row][col] = '#';
		
		for (int i = 0; i < 4; i++) {
			if (isSafe(display, row + rowNum[i], col + colNum[i])) {
				DFS(display, row + rowNum[i], col + colNum[i]);
			}
		}
	}
	
	
	//will write answer to solution file
	public static void writeAnswer(String path, int[] answers){
		BufferedReader br = null;
		File file = new File(path);
		// if file doesn't exist, then create it
		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fw);
			//write each answer on a new line
			for (int i = 0; i < answers.length; i++) {
				bw.write(answers[i] + "\n");	
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null) br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
}
