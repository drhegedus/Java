//Creator: Daphne Hegedus
//ID: 260762425
//Date: November 2018
//Collaborators: Haylee Luu, Nikoo Sarraf


import java.io.*;

public class balloon {
	
	
	public static void main(String[] args) {
		//FOR TIME CHECKING :
		//long startTime = System.currentTimeMillis();
		
		int[] answers = loadAndCall("testBalloons.txt"); //loads in the fill info and calls find answer on every problem
		
		//writes all the answers - in correct format - to file
		writeAnswer("testBalloons_solution.txt", answers);
		
		//FOR TIME CHECKING:
		//long endTime   = System.currentTimeMillis();
		//long totalTime = endTime - startTime;
		//System.out.println(totalTime);
		
	}
	
	//open the file and call findAnswer on every problem
	public static int[] loadAndCall(String fileName) {
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String currentLine = br.readLine();	//first line is the numOfProblems
			int numOfProblems = Integer.parseInt(currentLine);
			
			int[] answers = new int[numOfProblems];	//will be what we return
			
			int[] lengthOfProblems = new int[numOfProblems];	//will store the number of balloons in each problem
			currentLine = br.readLine();
			String[] lengths = currentLine.split(" ");
			for (int i = 0; i<lengths.length; i++) {
				lengthOfProblems[i] = Integer.parseInt(lengths[i]);	//change the strings to ints
			}
			
			String balloons = "";
			for (int i = 0; i < answers.length; i++) {
				balloons = br.readLine();						//get a string of the balloons with height separated by " "
				String[] currProblem = balloons.split(" ");
				int[] currBalloons = new int[currProblem.length];
				for (int j = 0; j < currProblem.length; j++) {
					currBalloons[j] = Integer.parseInt(currProblem[j]);	//change string array to int array
				}
				
				answers[i] = findAnswer(currBalloons);		//find answer and store result in returned int array -> then go to next problem
			}
			
			//close readers
			br.close();
			fr.close();
			
			//return the array of answers
			return answers;
			
		} catch (FileNotFoundException e1) {
			System.out.println("File not found.");
			e1.printStackTrace();
			return null;
		} catch (IOException e2) {
			System.out.println("IO Exception caught");
			e2.printStackTrace();
			return null;
		}
	}
	
	public static int findAnswer(int[] balloons) {
		int count = 0;		//will add up number of arrows used for specific problem
		
		for(int i = 0; i<balloons.length; i++) {
			if (balloons[i] == -1) continue;	//means balloon is already hit

			
			if (i == balloons.length - 1) {		// if last balloon
				if (balloons[i] != -1)  count ++; 	//its last balloon and hasn't been used = count ++ to hit it
				
			} else {
				int currHeight = balloons[i];		// of curr Balloon
				// flag it as visited (change height to -1)
				balloons[i] = -1;	
				int nextHeight = currHeight - 1;	// height looking for is 1 less
				int j = i+1;						// start looking at next balloon
				while(j < balloons.length){
					
					if (balloons[j] == -1) {		// if already hit -> move to next balloon and skip it
						j++;
						continue;
					}
					else if (balloons[j] == nextHeight) { //if balloon is at the correct height
					
						currHeight = balloons[j];			// new currHeight = this balloons height
						balloons[j] = -1;					// flag balloon as visited
						nextHeight --;						// next height will be one less
						
						if(currHeight == 1) break;			// if now at the bottom = stop loop
						}		
					else j++;							// balloon isn't at nextHeight = move to next one
				}
				count ++;			// num of arrows used ++
				
			}
		}
		
		return count;				// return number of arrows used
	}
	
	//will write answer to solution file
	public static void writeAnswer(String path, int[] answers){
		BufferedReader br = null;
		File file = new File(path);
		// if file doesn't exist, then create it
		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fw);
			//write each answer on a new line
			for (int i = 0; i < answers.length; i++) {
				bw.write(answers[i] + "\n");	
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null) br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	
	
}
