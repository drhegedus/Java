

//Creator: Daphne Hegedus
//ID: 260762425
//Date: November 2018
//Collaborators: Haylee Luu

import java.io.*;

public class mancala {
	
	public static void main(String[] args) {
		//FOR TIME CHECKING :
		//long startTime = System.currentTimeMillis();
		
		int[] answers = loadAndCall("testMancala.txt"); //loads in the fill info and calls find answer on every problem
		//writes all the answers - in correct format - to file
		writeAnswer("testMancala_solution.txt", answers);
		
		//FOR TIME CHECKING:
		//long endTime   = System.currentTimeMillis();
		//long totalTime = endTime - startTime;
		//System.out.println(totalTime);
		
	}
	
	//open the file and call findAnswer on every problem
	public static int[] loadAndCall(String fileName) {
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String currentLine = br.readLine();		//first line is the numOfProblems
			int numOfProblems = Integer.parseInt(currentLine);
			
			int[] answers = new int[numOfProblems];	//will be what we return
			int index = 0;
			currentLine = br.readLine();
		
			while (index < numOfProblems) {
				String[] board = currentLine.split(" ");
				int[] boardNum = new int[12];
				for (int i = 0; i<board.length; i++) {
					boardNum[i] = Integer.parseInt(board[i]);	//change the strings to ints
				}
					
				answers[index] = findAnswer(boardNum);			//find answer and store result in returned int array -> then go to next problem
				index ++;
				currentLine = br.readLine();

			}
	
			//close readers
			br.close();
			fr.close();
			
			//return the array of answers
			return answers;
			
		} catch (FileNotFoundException e1) {
			System.out.println("File not found.");
			e1.printStackTrace();
			return null;
		} catch (IOException e2) {
			System.out.println("IO Exception caught");
			e2.printStackTrace();
			return null;
		}
	}
	
	
	
	
	public static int findAnswer(int[] mancala) {
	
		if (validMoveLeft(mancala)) {		// if there is a valid move go through the minimum procedure
			//copy the data from mancala as to not change it for backtracking
			int[] copy = new int[12];
			//minNumber of pebbles begins at the max = 1's in every index = 12
			int min = 12;
			for (int i = 0; i < 12; i++) copy[i] = mancala[i];
			
			//check for 110 and if found -> perform move -> 001
			for (int i = 0; i<10; i++) {
				for (int j = 0; j < 12; j++) copy[j] = mancala[j];
				if (copy[i] == 1 && copy[i+1] == 1 && copy[i+2] == 0) {
					copy[i] = 0;
					copy[i+1] = 0;
					copy[i+2] = 1;
					//find the min answer with this version of the board
					int num = findAnswer(copy);
					//if number found is < current min = update it and move to next option
					if (num < min) min = num;
				}
			}
			//repeat process for 011 moves
			for (int i = 2; i<12; i++) {
				for (int j = 0; j < 12; j++) copy[j] = mancala[j];
				if (copy[i] == 1 && copy[i-1] == 1 && copy[i-2] == 0) {
					copy[i] = 0;
					copy[i-1] = 0;
					copy[i-2] = 1;
					int num = findAnswer(copy);
					if (num < min) min = num;
				}
			}
			return min;
			
		} else {													// if no valid move -> count up num of 1's in array
			int count = 0;
			for (int i = 0; i<12; i++) {
				if (mancala[i] == 1) {
					count++;
				}
			}
			return count;
		}
		
			
	}
	
	
	public static boolean validMoveLeft(int[] mancala) {
	//valid move is 011 or 110 somewhere in the array

		//110
		for (int i = 0; i<10; i++) {
			if (mancala[i] == 1 && mancala[i+1] == 1 && mancala[i+2] == 0) {
				return true;
			}
		}
		//011
		for (int i = 2; i<12; i++) {
			if (mancala[i] == 1 && mancala[i-1] == 1 && mancala[i-2] == 0) {
				return true;
			}
		}
		return false;	

	}

	
	//will write answer to solution file
	public static void writeAnswer(String path, int[] answers){
		BufferedReader br = null;
		File file = new File(path);
		// if file doesn't exist, then create it
		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fw);
			//write each answer on a new line
			for (int i = 0; i < answers.length; i++) {
				bw.write(answers[i] + "\n");	
			}
			
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null) br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
}
