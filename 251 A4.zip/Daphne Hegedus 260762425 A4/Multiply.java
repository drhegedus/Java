//Creator: Daphne Hegedus 260762425
//Date: November 2018
//Collaborators: Haylee Luu

import java.util.*;
import java.io.*;

public class Multiply{

    private static int randomInt(int size) {
        Random rand = new Random();
        int maxval = (1 << size) - 1;
        return rand.nextInt(maxval + 1);
    }
    
    public static int power2(double w) {
    	return (int) Math.pow(2,  w);
    }
    
    
    public static int[] naive(int size, int x, int y) {
    	
    	 // YOUR CODE GOES HERE  (Note: Change return statement)
    	
    	int[] toReturn = new int[2];
    	if (size == 1) {
    		toReturn[0] = x*y;
    		toReturn[1] += 1;
    		return toReturn;
    	} else {
    		double sizeToCost = size / 2.0;	//used only when finding the cost (to account for the data loss when dividing an odd number by two -> casting to int)
    		double m = Math.ceil((double)size/2);
        	int a = Math.floorDiv(x, power2(m));
        	int b = x % (power2(m));
        	int c = Math.floorDiv(y, power2(m));
        	int d = y % (power2(m));
        
        	int[] eArr = naive((int)m, a, c);
        	int[] fArr = naive((int)m, b, d);
        	int[] gArr = naive((int)m, b, c);
        	int[] hArr = naive((int)m, a, d);
        	
        	toReturn[0] = (power2(2.0*m))*eArr[0] + (power2(m))*(gArr[0] + hArr[0]) + fArr[0];
        	
        	toReturn[1] += eArr[1] + fArr[1] + gArr[1] + hArr[1] + (3*sizeToCost);
        	 return toReturn;

    	}
        
    }

    public static int[] karatsuba(int size, int x, int y) {
        
        // YOUR CODE GOES HERE  (Note: Change return statement)
        int[] toReturn = new int[2];
        if (size == 1) {
    		toReturn[0] = x*y;
    		toReturn[1] += 1;	
    		return toReturn;
    	} else {
    		double sizeToCost = size / 2.0;	//used only when finding the cost (to account for the data loss when dividing an odd number by two -> casting to int)
    		double m = Math.ceil((double)size/2);
        	int a = x / power2(m);
        	int b = x % (power2(m));
        	int c = y / power2(m);
        	int d = y % (power2(m));
        	 
	    	int[] eArr = karatsuba((int)m, a, c);
	    	int[] fArr = karatsuba((int)m, b, d);
	    	int[] gArr = karatsuba((int)m, (a-b), (c-d));
	    	
	    	toReturn[0] = (power2(2*m))*eArr[0] +  (power2(m))*(eArr[0] + fArr[0] - gArr[0]) + fArr[0];
        	toReturn[1] += eArr[1] + fArr[1] + gArr[1] + (6*sizeToCost);
        	 return toReturn;
    	}

        
    }
    
    public static void main(String[] args){

        try{
            int maxRound = 20;
            int maxIntBitSize = 16;
            for (int size=1; size<=maxIntBitSize; size++) {
                int sumOpNaive = 0;
                int sumOpKaratsuba = 0;
                for (int round=0; round<maxRound; round++) {
                    int x = randomInt(size);
                    int y = randomInt(size);
                    int[] resNaive = naive(size,x,y);
                    int[] resKaratsuba = karatsuba(size,x,y);
                    
            
                    if (resNaive[0] != resKaratsuba[0]) {
                        throw new Exception("Return values do not match! (x=" + x + "; y=" + y + "; Naive=" + resNaive[0] + "; Karatsuba=" + resKaratsuba[0] + ")");
                    }
                    
                    if (resNaive[0] != (x*y)) {
                        int myproduct = x*y;
                        throw new Exception("Evaluation is wrong! (x=" + x + "; y=" + y + "; Your result=" + resNaive[0] + "; True value=" + myproduct + ")");
                    }
                    
                    sumOpNaive += resNaive[1];
                    sumOpKaratsuba += resKaratsuba[1];
                }
                int avgOpNaive = sumOpNaive / maxRound;
                int avgOpKaratsuba = sumOpKaratsuba / maxRound;
                System.out.println(size + "," + avgOpNaive + "," + avgOpKaratsuba);
            }
        }
        catch (Exception e){
            System.out.println(e);
        }

   } 
}