package A2;

//CREATOR: Daphne Hegedus (260762425)
//DATE: October 2018
//COLLABORATORS: Haylee Luu

import java.util.*;

public class Kruskal{

    public static WGraph kruskal(WGraph g){

    	ArrayList<Edge> SortedE = g.listOfEdgesSorted();
    	WGraph mst = new WGraph();
    	
    	DisjointSets s = new DisjointSets(g.getNbNodes());
    	for (Edge e : SortedE) {
    		if (IsSafe(s, e)) {
    			s.union(e.nodes[0], e.nodes[1]);
    			mst.addEdge(e);
    		}
    	}
    	
        return mst;
    }

    public static Boolean IsSafe(DisjointSets p, Edge e){

        int sourceRep = p.find(e.nodes[0]);
        int endRep = p.find(e.nodes[1]);
        
        if (sourceRep == endRep) {
        	return false;
        }
        return true;
    
    }

    public static void main(String[] args){

        String file = args[0];
        WGraph g = new WGraph(file);
        WGraph t = kruskal(g);
        System.out.println(t);

   } 
}
