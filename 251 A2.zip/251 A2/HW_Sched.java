package A2;

//CREATOR: Daphne Hegedus (260762425)
//DATE: October 2018
//COLLABORATORS: Haylee Luu

import java.util.*;

class Assignment implements Comparator<Assignment>{
	int number;
	int weight;
	int deadline;
	
	
	protected Assignment() {
	}
	
	protected Assignment(int number, int weight, int deadline) {
		this.number = number;
		this.weight = weight;
		this.deadline = deadline;
	}
	

	
	/**
	 * This method is used to sort to compare assignment objects for sorting. 
	 * The way you implement this method will define which order the assignments appear in when you sort.
	 * Return -1 if a1 should appear after a2
	 * Return 1 if a1 should appear before a2
	 * Return 0 if a1 and a2 are equivalent 
	 */
	@Override
	public int compare(Assignment a1, Assignment a2) {
		//sorted in order of decreasing priority (aka: if a1 is before a2 then do a1 first)
		
		if (a1.deadline < a2.deadline) return -1;			// assignment w/ soonest deadline appears first
		else if (a2.deadline < a1.deadline) return 1;
		else if (a1.weight > a2.weight) return -1;			// if same deadline -> greatest weight appears first
		else if (a2.weight > a1.weight) return 1;
		
		return 0;											// otherwise they are equivalent	
														
	}
}

public class HW_Sched {
	ArrayList<Assignment> Assignments = new ArrayList<Assignment>();
	int m;
	int lastDeadline = 0;
	
	protected HW_Sched(int[] weights, int[] deadlines, int size) {
		for (int i=0; i<size; i++) {
			Assignment homework = new Assignment(i, weights[i], deadlines[i]);
			this.Assignments.add(homework);
			if (homework.deadline > lastDeadline) {
				lastDeadline = homework.deadline;
			}
		}
		m =size;
	}
	
	
	/**
	 * 
	 * @return Array where output[i] corresponds to when assignment #i will be completed. output[i] is 0 if assignment #i is never completed.
	 * The homework you complete first will be given an output of 1, the second, 2, etc.
	 */
	public int[] SelectAssignments() {
		//Use the following command to sort your Assignments: 
		//Collections.sort(Assignments, new Assignment());
		//This will re-order your assignments. The resulting order will depend on how the compare function is implemented
		
		ArrayList<Assignment> copy = new ArrayList<Assignment>();			// copy the Assignment list to preserve the correct indexes (before sorting)
		
		for (int i = 0; i < Assignments.size(); i++) {
			copy.add(Assignments.get(i));
		}
		
		Collections.sort(Assignments, new Assignment());
		
		//Initializes the homeworkPlan, which you must fill out and output
		int[] homeworkPlan = new int[Assignments.size()];
		//YOUR CODE GOES HERE
		
		int[] sortedPlan = new int[Assignments.size()];												//will store the indexes but in the order of the sorted Assignments ArrayList
		
		//how I implemented sort -> first value in sorted assignments should Always be done first
		sortedPlan[0] = 1;																			
		int nextIndex = 2;									//the next assignment to be done will be done 2nd (this will be incremented in for loop)
		int currDeadline = Assignments.get(0).deadline;		
		
		for( int i = 1; i < Assignments.size(); i++) {
			if (Assignments.get(i).deadline == currDeadline) sortedPlan[i] = 0;				//if it has the same deadline as one already done -> skip the assignment = store a 0
			else {																			// otherwise it is the next do-able and highest priority assignment = store the nextIndex (and increment it_
				sortedPlan[i] = nextIndex;
				nextIndex ++;
				currDeadline = Assignments.get(i).deadline;									// update the current deadline as well
			}
			
		}
		
		//sortedPlan now has all of the correct values but they are at the index in the sorted array
		//use the copy made before sorting to put the indexes in the right spot in homework plan

		for (int i = 0; i < homeworkPlan.length; i++) {
			int d = copy.get(i).deadline;															// deadline of assignment in original ArrayList
			int w = copy.get(i).weight;																// weight of assignment in original ArrayList
			for (int j = 0; j < sortedPlan.length; j++) {											// for every entry in the sorted Plan
				if (sortedPlan[j] != -1) {															// check for the flag
					if (w == Assignments.get(j).weight && d == Assignments.get(j).deadline) {		//compare deadlines and weights
						homeworkPlan[i] = sortedPlan[j];											// if same set the index in sortedPlan to homeworkPlan 
						sortedPlan[j] = -1;															//Change flag - signals that this assignment has already been used (for cases w an a1 and a2 that are equivalent)
					}
				}
			}
		}
		
		return homeworkPlan;						
	}
}
	



