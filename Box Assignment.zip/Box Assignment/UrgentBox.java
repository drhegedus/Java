package assignment2;

public class UrgentBox extends Box {
	
	UrgentBox(int height, int length, String id){
		super(height, length, id);
	}

}
