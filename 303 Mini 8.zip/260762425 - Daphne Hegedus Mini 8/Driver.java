//Creator: Daphne Hegedus
//StudentID: 260762425
//Date: November 2018

import java.util.ArrayList;

public class Driver {
	
	public static void main(String[] args) {
		
		Food banana = new Food("Banana", 27, 0, 1);
		Food egg = new Food("Egg", 0, 5, 6);
		Food bagel = new Food("Bagel", 56, 2, 11);
		ArrayList<Food> items = new ArrayList<Food>();
		items.add(banana);
		items.add(egg);
		items.add(bagel);
		
		//STRATEGY PATTERN
		Strategy<Food, String> s1 = new FoodNameStrategy();
		Strategy<Food, Integer> s2 = new FoodCalStrategy();
		ArrayList<Strategy> strats = new ArrayList<Strategy>();
		strats.add(s1);
		strats.add(s2);
		
		ArrayList<String> headers = new ArrayList<String>();
		headers.add("Name");
		headers.add("Calories");
		
		Table<Food> myStratTable = new Table<Food>(headers, strats, items);
		myStratTable.printTable();
		
		
		
		System.out.println("\n");
		
		//TEMPLATE PATTERN
		TableTM<Food> myTempTable = new FoodTable();
		myTempTable.TableTM(items, headers);
		
		
	}
}
