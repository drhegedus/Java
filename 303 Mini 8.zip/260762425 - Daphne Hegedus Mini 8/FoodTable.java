//Creator: Daphne Hegedus
//StudentID: 260762425
//Date: November 2018

import java.util.List;

public class FoodTable extends TableTM<Food> {

	protected String calculate(Food item) {
		String result = item.getName() + padding(item.getName(), 10);
		Integer cals = 4*item.getCarbs() + 9*item.getFat() + 4*item.getProtein();
		int numOfSpace = 3 - cals.toString().length();
		for (int i = 0; i<numOfSpace; i++) {
			result += " ";
		}
		result += cals.toString() + " cal";
		return result;
	}
	
	protected static String padding(String word, int maxLength) {
		String padding ="";
		int padNumber;
		padNumber = maxLength-word.length();

		for (int i=0; i<padNumber; i++) {
			padding +=" ";
		}
		return padding;
	}
	
	
	protected void printTable(List<String> rows, List<String> headers) {
		int lengthOfHeader = 0;
		for (String h : headers) {
			System.out.print(h + padding(h, 10));
			lengthOfHeader += padding(h, 10).length() + h.length();
		}
		System.out.println();
		for (int i = 0; i<lengthOfHeader; i++) {
			System.out.print("-");
		}
		System.out.println();

		for (String r : rows) {
			System.out.println(r);
		}
		
		
	}


}
