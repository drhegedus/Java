//Creator: Daphne Hegedus
//StudentID: 260762425
//Date: November 2018

import java.util.ArrayList;
import java.util.List;

public abstract class TableTM<T> {
	
	public final void TableTM(List<T> items, List<String> headers) {
		ArrayList<String> rows = new ArrayList<String>();
		for (T i : items) {
			rows.add(calculate(i));
		}
		printTable(rows, headers);
	}

	protected abstract void printTable(List<String> rows, List<String> headers);
	protected abstract String calculate(T item);
	
	
}