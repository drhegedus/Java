//Creator: Daphne Hegedus
//StudentID: 260762425
//Date: November 2018

public class FoodCalStrategy implements Strategy<Food, Integer> {

	public Integer calculate(Food item) {
		Integer calories = 4*item.getCarbs() + 9*item.getFat() + 4*item.getProtein();
		return calories;
	}


	public String toString(Integer cal) {
		String result = "";
		int numOfSpace = 3 - cal.toString().length();
		for (int i = 0; i<numOfSpace; i++) {
			result += " ";
		}
		result += cal.toString() + " cal";
		return result;
	}


	
}
