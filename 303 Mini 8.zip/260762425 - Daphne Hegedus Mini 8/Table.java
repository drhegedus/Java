//Creator: Daphne Hegedus
//StudentID: 260762425
//Date: November 2018

import java.util.List;
import java.util.ArrayList;

public class Table<T> {

		private List<T> items;		// actual items
		private List<String> rows;	// strings for printing
		private List<String> headers;
		private List<Strategy> strats;
		
		
		
		//index i of headers STRATEGY corresponds to index i of strats
		public Table(List<String> headers, List<Strategy> strats, List<T> items){
			if (headers.size() != strats.size()) throw new IllegalArgumentException();
			this.headers = headers;
			this.strats = strats;
			this.items = items;
			this.rows = new ArrayList<String>();
			for (T i  : items) {
				String thisRow = "";
				for (Strategy s : strats) {
					String curr = s.toString(s.calculate(i));
					thisRow += curr + padding(curr, 10);
				}
				this.rows.add(thisRow);
			}
			
		}
	
		public void addItem(T item) {
			this.items.add(item);
			String thisRow = "";
			for (Strategy s : strats) {
				String curr = s.toString(s.calculate(item));
				thisRow += curr + padding(curr, 10);
			}
			this.rows.add(thisRow);
		}
		
		public void removeItem(T item) {
			for (T i : items) {
				if (i.equals(item)) {
					this.rows.remove(this.items.indexOf(i));
					this.items.remove(i);
					break;
				}
			}
		}
		
		//for lining up the printTable() method
		public static String padding(String word, int maxLength) {
			String padding ="";
			int padNumber;
			padNumber = maxLength-word.length();

			for (int i=0; i<padNumber; i++) {
				padding +=" ";
			}
			return padding;
		}
		
		public void printTable() {
			int lengthOfHeader = 0;
			for (String h : headers) {
				System.out.print(h + padding(h, 10));
				lengthOfHeader += padding(h, 10).length() + h.length();
			}
			System.out.println();
			for (int i = 0; i<lengthOfHeader; i++) {
				System.out.print("-");
			}
			System.out.println();

			for (String r : rows) {
				System.out.println(r);
			}
			
			
			
			
		}
}
