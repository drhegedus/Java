//Creator: Daphne Hegedus
//StudentID: 260762425
//Date: November 2018

public class FoodNameStrategy implements Strategy<Food, String> {
	
	public String calculate(Food item) {
		return item.getName();
	}

	public String toString(String name) {
//		int numOfSpaces = 8 - name.length();
//		String result = "";
//		for (int i = 0; i < numOfSpaces; i++) {
//			result += " ";
//		}
//		return result + name;
		
		//IF WANT TO ALIGN RIGHT ^^
		
		return name;
	}


}
