//Creator: Daphne Hegedus
//StudentID: 260762425
//Date: November 2018

public interface Strategy<T, E> {
	public E calculate(T item);
	public String toString(E value);

}
