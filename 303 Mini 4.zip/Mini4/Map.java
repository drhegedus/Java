
/**
 * <h1> Map CLASS </h1>
 * This class creates a 2D array Map (of a specified size) that can be populated with characters
 * 
 * @author Daphne Hegedus 
 * (ID 269762425)
 * @since October 2018
 * @version 1.0
 * */
public class Map {
	private char[][] map;
	private int maxRow;
	private int maxWidth;
	
	
	/**
	 * This method initializes a 2D array Map and fills it with '~'
	 * @param row height of instance
	 * @param column length of instance
	 * @throws IllegalArgumentException if row and column are invalid
	 */
	public Map(int row, int column) throws IllegalArgumentException {
		if (row <= 0 || column <= 0) {									
			throw new IllegalArgumentException();
		} else {
			this.maxRow = row;								
			this.maxWidth = column;
			this.map = new char[this.maxRow][this.maxWidth];			
			for (int i = 0; i<this.maxRow; i++) {						
				for (int j = 0; j<this.maxWidth; j++) {
					this.map[i][j] = '~';
				}
			}
		}

	}
	
	/**
	 * 
	 * @return maxRow for instance
	 */
	public int getMaxRow(){
		try {
			return this.maxRow;
		} catch (Exception e) {
			return -1;
		}
	}
	
	/**
	 * 
	 * @return maxWidth for instance
	 */
	public int getMaxWidth(){
		try {
			return this.maxWidth;
		} catch (Exception e) {
			return -1;
		}
	}
	
	/**
	 * 
	 * @param row to access
	 * @param column to access
	 * @return charAtPosition
	 */
	public char getChar(int row, int column){
		try {
			return this.map[row][column];
		} catch (Exception e){
			return ' ';
		}
	}
	
	
	/**
	 * This method places the specified character (~, G, or #) in this instance of Map.	
	 *@param row x coordinate to place char
	 *@param column y coordinate to place char
	 *@param symbol char to place (tested to see if ~, G, or #)
	 *@return boolean This returns true if char was valid and placed, false otherwise
	 */
	public boolean placeNewChar(int row, int column, char symbol) {
		try {
			if (symbol == '~' || symbol == '#' || symbol == 'G') {
				this.map[row][column] = symbol;							
				return true;
			} else return false;
		} catch (Exception e) {											
			return false;
		}
																		
	}
	
	
	
	/**
	 * This class creates prints the 2D array Map to the display
	 */	
	public void printMap() {							
		try {
			for (int i= 0; i<maxRow; i++) {
				for (int j = 0; j<maxWidth; j++) {
					System.out.print(this.map[i][j]);
				}
				System.out.println();									
				
			}
		} catch (Exception e) {
			System.out.println("Map requested doesn't exist.");
		}
	}
}
