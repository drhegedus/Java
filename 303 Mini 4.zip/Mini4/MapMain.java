
import java.util.Scanner;

/**
*<h1> MapMain CLASS </h1> The MapMain Program provides the user interface for a Map
*
*@author Daphne Hegedus 
*(ID 260762425)
*@since October 2018
*@version 1.0
*/
public class MapMain {
	
	/**
	 * The main method here creates a map based on user input and provides the main menu function of the program
	 * @param args not used
	 */
	public static void main(String[] args) {
		
		System.out.println("Welcome to Map!");
		
		Scanner UserInputs = new Scanner(System.in);													
		
		/**
		 * creates map from users inputs
		 */
		int maxRow = askForMaxVal("Row", UserInputs);
		int maxColumn = askForMaxVal("Column", UserInputs);
		
		Map myMap = new Map(maxRow, maxColumn);													
		System.out.println("Map has been created. \n");

		/**
		 * enters a while loop of main menu that will keep asking after every addition to map if want to do something else
		 */
		boolean again = true;																			
		while (again == true) {																			
												
			System.out.println("Please add an object to the map (~ for water, G for grass, # for tree)");
			int row = askForLocation("Row", maxRow, UserInputs);													
			int column = askForLocation("Column", maxColumn, UserInputs);
			char symbol = askForChar(UserInputs);																	
			
			
			/**
			 * places char choice in map
			 */
			myMap.placeNewChar(row, column, symbol);													
			System.out.println("\n Your " + symbol + " was added to " + row + "," + column + " in the map.");
			
			
			/**
			 * asks if want to go again (Y for yes, N for no).
			 * If no boolean flag is changed to false and while loop is exited
			 */
			System.out.print("Would you like to enter another character? (Y/N) : ");
			
			char answer = UserInputs.next().charAt(0);		
			
			while (answer != 'N' && answer != 'Y') {													
				System.out.println("Please answer with a Y for yes or an N for no.");
				System.out.print("Would you like to enter another character? (Y/N) : ");
				answer = UserInputs.next().charAt(0);					
			}
			
			if (answer == 'N') {																		
				again = false;																			
			}
			
		}
		
		/**
		 * prints final map
		 */
		myMap.printMap();																				
		
	}
	
	
	/**
	 * asForMaxVal asks user for either the maxWidth or maxRow of the map to be created based on the param of valueType
	 * @param valueType will either be "Row" or "Column"
	 * @param UserInputs the scanner to interact with user
	 * @return maxVal either the width or height of map depending on valueType
	 */
	public static int askForMaxVal(String valueType, Scanner UserInputs) {
		int maxVal = 0;																					
		while (maxVal < 1) {																			
		    System.out.print("Please input the maximum number of " + valueType + "s: ");		
		    String next = UserInputs.next();									
		    /**
	    	 * checks that input is a valid integer > 0
	    	 */
		    try {
		    	maxVal = Integer.parseInt(next);														
		    } catch (NumberFormatException exp) {
		    	System.out.println("A " + valueType + " must be an integer. \n");	
		    	continue;
		    }
		    if (maxVal < 1 ) {																			
		    	System.out.println("A " + valueType + " must be greater than 0. \n");
		    }
		}
		
		return maxVal;
	}
	
	
	/**
	 * askForLocation will ask user for either the row or column to place a character in
	 * @param type either "Row" or "Column"
	 * @param max is maxRow if type is "Row" and is maxWidth is type is "Column"
	 * @param UserInputs scanner to interact with user
	 * @return location a coordinate that is either the row or column location for char to be placed
	 */
	public static int askForLocation(String type, int max, Scanner UserInputs) {
		int location = -1;																				
		while (location < 0 || location > max) {																			
		    System.out.print(type + ": ");																
		    String next = UserInputs.next();
		    /**
	    	 * checks that input is a valid integer between zero and the max value for that coordinate
	    	 */
		    try {
		    	location = Integer.parseInt(next);
		    } catch (NumberFormatException exp) {
		    	System.out.println("A " + type + " must be an integer. \n");
		    	continue;
		    }						
		    if (location < 0 || location > max) {														
		    	System.out.println("Invalid " + type + "! Must be between 0 and " + (max - 1) + ". \n");
		    }
		}
		
		return location;
	}
	
	/**
	 * askForChar ask user for a valid character to place in the map
	 * @param UserInputs scanner to interact with user
	 * @return symbol the character to be placed in the map
	 */
	public static char askForChar(Scanner UserInputs) {
		
		System.out.print("Character: ");
		char symbol = UserInputs.next().charAt(0);
		/**
		 * checks the input is a valid char (#, ~, or G)
		 */
		while (symbol != '~' && symbol != 'G' && symbol != '#') {										
			System.out.println("Invalid character! Must be either ~ or G or #. \n");
			System.out.print("Character: ");
			symbol = UserInputs.next().charAt(0);
		}
		
		return symbol;
	}
	
}

