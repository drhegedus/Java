
import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;

/**
*<h1> TestMap CLASS </h1> The MapMain Program provides tester for Map.java in jUnit
*@author Daphne Hegedus 
*(ID 260762425)
*@since October 2018
*@version 1.0
*/
public class MapTest {

	
	
	@Test
	public void testMap() {
		try {
			/**
			 * Valid inputs tested.
			 */
			Map m1 = new Map(1, 1);
			Map m5 = new Map(5, 4);
			Map m6 = new Map(20, 14);
			
			/**
			 * Invalid inputs tested.
			 */
			Map m2 = new Map(0, 1);
			Map m3 = new Map(1, -1);
			Map m4 = new Map(0, 0);
		
			assertEquals(m1.getMaxRow(), 1);
			assertEquals(m1.getMaxWidth(), 1);
			assertEquals(m2.getMaxRow(), 0);
			assertEquals(m2.getMaxWidth(), 1);
			assertEquals(m3.getMaxRow(), 1);
			assertEquals(m3.getMaxWidth(), -1);
			assertEquals(m4.getMaxRow(), 0);
			assertEquals(m4.getMaxWidth(), 0);
			assertEquals(m5.getMaxRow(), 5);
			assertEquals(m5.getMaxWidth(), 4);
			assertEquals(m6.getMaxRow(), 20);
			assertEquals(m6.getMaxWidth(), 14);
		} catch (IllegalArgumentException e) {}
	}
	
	
	
	
	@Test
	public void testGetMaxRow() {
		try {	
			/**
			 * Valid inputs tested.
			 */
			Map m1 = new Map(1, 1);
			Map m5 = new Map(5, 4);
			Map m6 = new Map(20, 14);
			
			/**
			 * Invalid inputs tested.
			 */
			Map m2 = new Map(0, 1);
			Map m3 = new Map(1, -1);
			Map m4 = new Map(0, 0);
		
			assertEquals(m1.getMaxRow(), 1);
			assertEquals(m2.getMaxRow(), 0);
			assertEquals(m3.getMaxRow(), 1);
			assertEquals(m4.getMaxRow(), 0);
			assertEquals(m5.getMaxRow(), 5);
			assertEquals(m6.getMaxRow(), 20);
		} catch (IllegalArgumentException e) {}
	}

	
	
	
	@Test
	public void testGetMaxWidth() {
		try {	
			/**
			 * Valid inputs tested.
			 */
			Map m1 = new Map(1, 1);
			Map m5 = new Map(5, 4);
			Map m6 = new Map(20, 14);
			
			/**
			 * Invalid inputs tested
			 */
			Map m2 = new Map(0, 1);
			Map m3 = new Map(1, -1);
			Map m4 = new Map(0, 0);

		
			assertEquals(m1.getMaxWidth(), 1);
			assertEquals(m2.getMaxWidth(), 1);
			assertEquals(m3.getMaxWidth(), -1);
			assertEquals(m4.getMaxWidth(), 0);
			assertEquals(m5.getMaxWidth(), 4);
			assertEquals(m6.getMaxWidth(), 14);
			
		} catch (IllegalArgumentException e) {}
	}
	
	
	
	
	@Test
	public void testGetChar() {
		Map myMap = new Map(10, 10);
		
		/**
		 * Map is 10 x 10
		 * valid inputs : 0 - 9 (row and column)
		 * invalid inputs : < 0 or > 9
		 * if unplaced the map should be pre-populated with '~'
		 */
		
		try {
			myMap.placeNewChar(0, 0, '#');
			myMap.placeNewChar(4, 5, 'G');
			myMap.placeNewChar(0, 9, '~');
			
			assertEquals(myMap.getChar(0, 0), '#');
			assertEquals(myMap.getChar(4, 5), 'G');
			assertEquals(myMap.getChar(0, 9), '~');
			assertEquals(myMap.getChar(0, 7), '~');
			
			myMap.placeNewChar(-1, 5, '#');
			myMap.placeNewChar(3, 10, '#');
		
			
			
		} catch (Exception e) {} 
		
	}
	
	
	

	@Test
	public void testPlaceNewChar() {
		/**
		 * Tested on maps 4x4, 9x5, 2x10 with all three char choices.
		 * All chars not specified should be pre-populated with '~'.
		 * Valid choices tested.
		 */
		try {
			Map m1 = new Map(4, 4);
			m1.placeNewChar(0, 0, '#');
			m1.placeNewChar(1, 2, 'G');
			
			Map m2 = new Map(9, 5);
			m2.placeNewChar(4, 3, '#');
			m2.placeNewChar(8, 1, '~');
			
			Map m3 = new Map(2, 10);
			m3.placeNewChar(0, 8, 'G');
			m3.placeNewChar(1, 2, 'G');
			
			
			for(int i = 0; i < m1.getMaxRow(); i++) {
				for (int j = 0; j < m1.getMaxWidth(); j++) {
					if (i == 0 && j == 0) {
						assertEquals(m1.getChar(i, j), '#');
					} else if (i == 1 && j == 2) {
						assertEquals(m1.getChar(i, j), 'G');
					} else { 
						assertEquals(m1.getChar(i, j), '~');
					}
				}
			}
			
			for (int i = 0; i < m2.getMaxRow(); i++) {
				for (int j = 0; j < m2.getMaxWidth(); j++) {
					if (i == 4 && j == 3) {
						assertEquals(m2.getChar(i, j), '#');
					} else if (i == 8 && j == 1) {
						assertEquals(m2.getChar(i, j), '~');
					} else { 
						assertEquals(m2.getChar(i, j), '~');
					}
				}
			}
			
			for(int i = 0; i < m3.getMaxRow(); i++) {
				for (int j = 0; j < m3.getMaxWidth(); j++) {
					if (i == 0 && j == 8) {
						assertEquals(m3.getChar(i, j), 'G');
					} else if (i == 1 && j == 2) {
						assertEquals(m3.getChar(i, j), 'G');
					} else { 
						assertEquals(m3.getChar(i, j), '~');
					}
				}
			}
			
			/**
			 * Invalid choices tested on map of 4x4 (invalid location or invalid symbol).
			 */
		
			m1.placeNewChar(-1, 3, 'G'); 
			m1.placeNewChar(3, 15, '#'); 
			m1.placeNewChar(-2, 4, 'G'); 
			m1.placeNewChar(2, 3, 'D'); 
			
			
		} catch (Exception e) { }
	}
	
	
	
	
	@Test
	public void testPrintMap() {
		
		/**
		 * Tested on maps 4x4, 9x5, 2x10 with all three char choices.
		 * All chars not specified should be pre-populated with '~'.
		 */
		Map m1 = new Map(4, 4);
		m1.placeNewChar(0, 0, '#');
		m1.placeNewChar(1, 2, 'G');
		
		Map m2 = new Map(9, 5);
		m2.placeNewChar(4, 3, '#');
		m2.placeNewChar(8, 1, '~');
		
		Map m3 = new Map(2, 10);
		m3.placeNewChar(0, 8, 'G');
		m3.placeNewChar(1, 2, 'G');
		
		
		try {
			m1.printMap();
			System.out.println();
			m2.printMap();
			System.out.println();
			m3.printMap();
			System.out.println();
		} catch (Exception e) { 
			System.out.println("Error in printMap()");
		}
		
		
	}

}


