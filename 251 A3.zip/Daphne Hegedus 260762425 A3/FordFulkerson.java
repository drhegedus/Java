//CREATOR: Daphne Hegedus (260762425)
//DATE: November 2018
//COLLABORATORS: Haylee Luu

import java.io.*;
import java.util.*;


public class FordFulkerson {
	
	public static ArrayList<Integer> pathDFS(Integer source, Integer destination, WGraph graph){
		
		ArrayList<Integer> Stack = new ArrayList<Integer>();
		
		Stack.add(source);
		
		ArrayList<Integer> reachable = new ArrayList<Integer>();
		ArrayList<Edge> edges = graph.getEdges();
		for (int i = 0; i<edges.size(); i++) {
			Edge e = edges.get(i);
			if (e.nodes[0] == source && e.weight > 0) {
				reachable.add(e.nodes[1]);

			}
		}
		
		for (int j = 0; j<reachable.size(); j++) {
			if (reachable.get(j) == destination) {
				Stack.add(destination);
				return Stack;
			}
		}
		
		for (int i = 0; i<reachable.size(); i++) {
			Integer node = reachable.get(i);
			if (node != null) {
				WGraph g2 = new WGraph(graph);
				g2.setEdge(source, node, 0);
				ArrayList<Integer> returned = pathDFS(node, destination, g2);
				if (returned.size() != 0 && returned.get(returned.size() - 1) == destination) {
					Stack.addAll(returned);
					break;
				}
			}
		}
		if (Stack.size() == 1) {
			Stack.remove(0);
		}

		
		return Stack;
		
	}
	
	
	public static void fordfulkerson(Integer source, Integer destination, WGraph graph, String filePath){
		String answer="";
		String myMcGillID = "000000000"; //Please initialize this variable with your McGill ID
		int maxFlow = 0;
		
		
		WGraph residual = new WGraph(graph);
		ArrayList<Integer> path = pathDFS(source, destination, residual);
		
		while (path.size() != 0) {
			int bottleNeck = Integer.MAX_VALUE;
			for (int i = 0; i<path.size()-1; i++) {
				Edge e = residual.getEdge(path.get(i), path.get(i+1));
				if (e.weight < bottleNeck) bottleNeck = e.weight;
			}
			
			for (int i = 0; i<path.size()-1; i ++) {
				Integer start = path.get(i);
				Integer end = path.get(i+1);
				int w = residual.getEdge(start, end).weight;
				residual.setEdge(end, start, bottleNeck);
				residual.setEdge(start, end, w-bottleNeck);
			}
			maxFlow += bottleNeck;
			path = pathDFS(source, destination, residual);
		}
		
		for (Edge e : graph.getEdges()) {
			int r = residual.getEdge(e.nodes[0], e.nodes[1]).weight;
			graph.setEdge(e.nodes[0], e.nodes[1], e.weight - r);
		}
		
		
		
		answer += maxFlow + "\n" + graph.toString();	
		writeAnswer(filePath+myMcGillID+".txt",answer);
		System.out.println(answer);
	}
	
	
	public static void writeAnswer(String path, String line){
		BufferedReader br = null;
		File file = new File(path);
		// if file doesnt exists, then create it
		
		try {
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(line+"\n");	
		bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	 public static void main(String[] args){
		 String file = args[0];
		 File f = new File(file);
		 WGraph g = new WGraph(file);
		 ArrayList<Integer> path = pathDFS(g.getSource(), g.getDestination(), g);
		 for (int i = 0; i<path.size(); i++) {
			 System.out.println(path.get(i));
		 }
		 System.out.println();
		 fordfulkerson(g.getSource(),g.getDestination(),g,f.getAbsolutePath().replace(".txt",""));
	 }
}
