package assignment3;

public class Building {

	OneBuilding data;
	Building older;
	Building same;
	Building younger;
	
	public Building(OneBuilding data){
		this.data = data;
		this.older = null;
		this.same = null;
		this.younger = null;
	}
	
	public String toString(){
		String result = this.data.toString() + "\n";
		if (this.older != null){
			result += "older than " + this.data.toString() + " :\n";
			result += this.older.toString();
		}
		if (this.same != null){
			result += "same age as " + this.data.toString() + " :\n";
			result += this.same.toString();
		}
		if (this.younger != null){
			result += "younger than " + this.data.toString() + " :\n";
			result += this.younger.toString();
		}
		return result;
	}
	
	public Building addBuilding (OneBuilding b){
		if (this.data.equals(b) || this.data == null) { 
			this.data = b;
		} else if (b.yearOfConstruction > this.data.yearOfConstruction) {                                                                 
				if (this.younger == null) {
					this.younger = new Building(b);
				} else {
					this.younger.addBuilding(b);
				}
		} else if (b.yearOfConstruction < this.data.yearOfConstruction) {
			if (this.older == null) {
				this.older = new Building(b);
			} else {
				this.older.addBuilding(b);
			}		
		} else if (b.yearOfConstruction == this.data.yearOfConstruction) {
			if (this.data.height >= b.height) {
				if (this.same == null) {
					this.same = new Building(b);
				} else {
					this.same.addBuilding(b);
				}
			} else {
			
				//temp variables:
				Building old = this.older;
				Building young = this.younger;
				Building same = this.same;
				OneBuilding root = this.data;
				
				//building w/ b as root:
				Building temp = new Building(b);
				temp.older = old;
				temp.younger = young;
				temp.same = same;
				temp.addBuilding(root);
				
				//update:
				this.data = temp.data;
				this.older = temp.older;
				this.younger = temp.younger;
				this.same = temp.same;
			}
		}
		return this;
	}
	
	public Building addBuildings (Building b){
		if (b == null) {
			return this;
		} else {
			this.addBuilding(b.data);
			this.addBuildings(b.older);
			this.addBuildings(b.same);
			this.addBuildings(b.younger);
			return this;
			
		}
	}
	
	public Building removeBuilding (OneBuilding b){
		
		Building youngTemp = null;
		Building sameTemp = null;
		Building oldTemp = null;
		
		if (this.findRootofSub(b) == null) { 
				return this; 
		} else if (this.data.name == b.name && this.data.height == b.height && this.data.costForRepair == b.costForRepair && this.data.yearOfConstruction == b.yearOfConstruction && this.data.yearForRepair == b.yearForRepair) {
			if (this.younger!=null) {
				youngTemp = this.younger;
			}
			if (this.same!=null) {
				sameTemp = this.same;
			}
			if (this.older!=null) {
				oldTemp = this.older;
			} if (this.same != null) {
				Building check = new Building(this.same.data);
				check.addBuildings(youngTemp);
				if (sameTemp.same != null) { check.addBuildings(sameTemp.same); }
				if (sameTemp.younger != null) { check.addBuildings(sameTemp.younger); }
				if (sameTemp.older != null) { check.addBuildings(sameTemp.older); }
				check.addBuildings(oldTemp);
				this.data = null;
				if (this.younger != null) { this.younger=null; }
				if (this.same != null) { this.same=null; }
				if (this.older != null) { this.older = null; }
				this.data = check.data;
				this.older = check.older;
				this.same = check.same;
				this.younger = check.younger;
				return this;
			} else if (this.same == null && this.older != null) {
				Building check = new Building(this.older.data);
				check.addBuildings(youngTemp);
				check.addBuildings(sameTemp);
				if (oldTemp.older != null) { check.addBuildings(oldTemp.older); }
				if (oldTemp.younger != null) { check.addBuildings(oldTemp.younger); }
				if (oldTemp.same != null) { check.addBuildings(oldTemp.same); }
				this.data = null;
				if (this.younger != null) { this.younger = null; }
				if (this.same != null) { this.same = null; }
				if(this.older != null) { this.older = null; }
				this.data = check.data;
				this.older = check.older;
				this.same = check.same;
				this.younger = check.younger;
				return this;
			} else if (this.same == null && this.older == null && this.younger == null) { return null; }
		}
		else if (this.findRootofSub(b).younger == null && this.findRootofSub(b).same == null && this.findRootofSub(b).younger == null) {
			Building check = this.findParentofNode(b);
			if (check.older != null && check.older.data.equals(b)) { check.older = null; }
			if (check.younger != null && check.younger.data.equals(b)) { check.younger = null; }
			if (check.same != null && check.same.data.equals(b)) { check.same = null; }
			return this;
		} else {	
			Building check = this.findRootofSub(b).removeBuilding(b);
			this.addBuildings(check);
			return this; 
		}
		
		return this; 
	}
	
	public int oldest(){
		if (this.older == null) { 
			return this.data.yearOfConstruction; 
		} else {
			return this.older.oldest();
		}
	}
	
	public int highest(){
		if (this.data != null && this.younger != null && this.same != null && this.older != null) {
			int currHeight = this.data.height;
			int highestofYounger = this.younger.highest();
			int highestofSame = this.same.highest();
			int highestofOlder = this.older.highest();
			if (currHeight >= highestofYounger && currHeight >= highestofSame && currHeight >= highestofOlder) {
				return currHeight;
			} else if (highestofYounger > currHeight && highestofYounger > highestofSame && highestofYounger  > highestofOlder) {
				return highestofYounger;
			}
			else if (highestofSame > highestofYounger && highestofSame > currHeight && highestofSame > highestofOlder) {
				return highestofSame;
			}
			else return highestofOlder;
		}
		else if (this.data != null && this.younger != null && this.same != null) {
			int currHeight = this.data.height;
			int highestofYounger = this.younger.highest();
			int highestofSame = this.same.highest();
			if (currHeight >= highestofYounger && currHeight >= highestofSame) {
				return currHeight;
			}
			else if (highestofYounger > currHeight && highestofYounger > highestofSame) { 
				return highestofYounger;
			} else {
				return highestofSame;
			}
		}
		else if (this.data != null && this.younger != null && this.older != null) {
			int currHeight = this.data.height;
			int highestofYounger = this.younger.highest();
			int highestofOlder = this.older.highest();
			if (currHeight >= highestofYounger && currHeight >= highestofOlder) { return currHeight; }
			else if (highestofYounger > currHeight && highestofYounger > highestofOlder) { return highestofYounger; }
			else { return highestofOlder; }
		}
		else if (this.data != null && this.same != null && this.older != null) {
			int currHeight = this.data.height;
			int highestofSame = this.same.highest();
			int highestofOlder = this.older.highest();
			if (currHeight >= highestofSame && currHeight >= highestofOlder) { return currHeight; }
			else if (highestofSame > currHeight && highestofSame > highestofOlder) { return highestofSame; }
			else { return highestofOlder; }
		}
		else if (this.data != null && this.younger != null) {
			int currHeight = this.data.height;
			int highestofYounger = this.younger.highest();
			if (currHeight >= highestofYounger) { return currHeight; }
			else { return highestofYounger; }
		}
		else if (this.data != null && this.same != null) {
			int currHeight = this.data.height;
			int highestofSame = this.same.highest();
			if (currHeight >= highestofSame) { return currHeight; }
			else { return highestofSame; }
		}
		else if (this.data != null && this.older != null) {
			int currHeight = this.data.height;
			int highestofOlder = this.older.highest();
			if (currHeight >= highestofOlder) { return currHeight; }
			else { return highestofOlder; }
		}

		return this.data.height;
	}
	
	public OneBuilding highestFromYear (int year){
		if (this.BuildInYear(year) == false) return null;
		else if (this.data.yearOfConstruction == year) return this.data;
		else if (this.data.yearOfConstruction > year && this.older != null) { return this.older.highestFromYear(year); }
		else if (this.data.yearOfConstruction < year && this.younger != null) { return this.younger.highestFromYear(year); }
		return null;
	}
	
	public int numberFromYears (int yearMin, int yearMax){
		if (yearMin > yearMax) return 0;
		int numberOfBuildings = 0;
		for (int i = yearMin; i <= yearMax; i++) {
			numberOfBuildings += this.numofBuildings(i);
		}
		return numberOfBuildings;
	}
	
	public int[] costPlanning (int nbYears){
		int[] cost = new int[nbYears];
		for (int i = 0; i < cost.length; i++) {
			cost[i] = this.numOfRepairs(2018+i);
		}
		return cost;
	}
	
	public Building findRootofSub (OneBuilding b) {
		if (this.data == null) return null;
		else if (this.data.name.equals(b.name) && this.data.yearOfConstruction == b.yearOfConstruction && this.data.height == b.height && this.data.yearForRepair == b.yearForRepair && this.data.costForRepair == b.costForRepair) {
			return this;
		}
		else if (this.data.yearOfConstruction == b.yearOfConstruction && this.data != b && this.same != null) { return this.same.findRootofSub(b); }
		else if (this.data.yearOfConstruction > b.yearOfConstruction && this.older != null) { return this.older.findRootofSub(b); }
		else if (this.data.yearOfConstruction < b.yearOfConstruction && this.younger != null) { return this.younger.findRootofSub(b); }
		return null;
	}
	
	
	public Building findParentofNode (OneBuilding b) {
		if (this.data == null) { return null; }
		 if (this.younger != null && this.younger.data.name.equals(b.name) && this.younger.data.yearOfConstruction == b.yearOfConstruction && this.younger.data.height == b.height && this.younger.data.yearForRepair == b.yearForRepair) {
			return this;
		}
		else if (this.same != null && this.same.data.name.equals(b.name) && this.same.data.yearOfConstruction == b.yearOfConstruction && this.same.data.height == b.height && this.same.data.yearForRepair == b.yearForRepair) {
			return this;
		}
		else if (this.older != null && this.older.data.name.equals(b.name) && this.older.data.yearOfConstruction == b.yearOfConstruction && this.older.data.height == b.height && this.older.data.yearForRepair == b.yearForRepair) {
			return this;
		}
		else if (this.younger != null && this.data.yearOfConstruction < b.yearOfConstruction) { return this.younger.findParentofNode(b); }
		else if (this.same!=null && this.data.yearOfConstruction==b.yearOfConstruction) { return this.same.findParentofNode(b); }
		else if (this.older!=null && this.data.yearOfConstruction>b.yearOfConstruction) { return this.older.findParentofNode(b); }
		return null;
	}
	
	public int numOfRepairs(int year) {
		if (this.data == null) { 
			return 0; 
		} else if (this.data.yearForRepair == year) {
			if (this.younger != null && this.same != null && this.older != null) {
				return this.data.costForRepair + this.younger.numOfRepairs(year) + this.same.numOfRepairs(year) + this.older.numOfRepairs(year);
			}
			else if (this.younger != null && this.same != null) {
				return this.data.costForRepair + this.younger.numOfRepairs(year) + this.same.numOfRepairs(year);
			}
			else if (this.younger != null && this.older != null) {
				return this.data.costForRepair + this.younger.numOfRepairs(year) + this.older.numOfRepairs(year);
			}
			else if (this.older != null && this.same != null) {
				return this.data.costForRepair + this.older.numOfRepairs(year) + this.same.numOfRepairs(year);
			}
			else if (this.younger != null) {
				return this.data.costForRepair + this.younger.numOfRepairs(year);
			}
			else if (this.same != null) {
				return this.data.costForRepair + this.same.numOfRepairs(year);
			}
			else if (this.older != null) {
				return this.data.costForRepair + this.older.numOfRepairs(year);
			} else {
				return this.data.costForRepair;
			}
		} else if (this.younger != null && this.same != null && this.older != null) {
			return this.younger.numOfRepairs(year) + this.same.numOfRepairs(year) + this.older.numOfRepairs(year);
		}
		else if (this.younger != null && this.same != null) {
			return this.younger.numOfRepairs(year) + this.same.numOfRepairs(year);
		}
		else if (this.younger != null && this.older != null) {
			return this.younger.numOfRepairs(year) + this.older.numOfRepairs(year);
		}
		else if (this.older != null && this.same != null) {
			return this.older.numOfRepairs(year) + this.same.numOfRepairs(year);
		}
		else if (this.younger != null) {
			return this.younger.numOfRepairs(year);
		}
		else if (this.same != null) {
			return this.same.numOfRepairs(year);
		}
		else if (this.older != null) {
			return this.older.numOfRepairs(year);
		} else {
			return 0;
		}
	}


	
	public boolean BuildInYear (int year) {
		if (this.data == null) { return false; }
		else if (this.data.yearOfConstruction == year) { return true; }
		else if (this.data.yearOfConstruction > year && this.older != null) { return this.older.BuildInYear(year); }
		else if (this.data.yearOfConstruction < year && this.younger != null) { return this.younger.BuildInYear(year); }
		return false;
	}
	
	
	public int numofBuildings(int year) {
		Building check = new Building(this.data);
		if (this.younger != null) { check.addBuildings(this.younger); }
		if (this.same != null) { check.addBuildings(this.same); }
		if (this.older != null) { check.addBuildings(this.older); }
		int count = 0;
		if (check.data.yearOfConstruction == year) {
			count = 1;
		}
		if (check.data.yearOfConstruction == year && check.same!=null) {
			count = 2;
			while (check.same.same != null) {
				count ++;
				check.same = check.same.same;
			}
		}
		else if (check.data.yearOfConstruction<year && check.younger != null) return check.younger.numofBuildings(year);
		else if (check.data.yearOfConstruction>year && check.older != null) return check.older.numofBuildings(year);
		return count;
	}
	
}
